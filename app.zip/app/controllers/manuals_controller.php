<?php
class ManualsController extends AppController {

//	var $name = 'Staffs';
	var $uses = array('Staff');
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Staff->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function index() {
		$userLevel = $this->Auth->user('level');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "index_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "index_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "index_admin";			
		}
		$this->render( $viewTemplate );
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

}
?>