<?php
class ShopsController extends AppController {

	var $name = 'Shops';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Shop->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$userLevel = $this->Auth->user('level');
		if ( $userLevel != 9 ) {
			$this->redirect(array('controller' => 'staffs', 'action' => 'login'));
		}
		
		$option = array(
			'conditions' => array(
			'Shop.kind_id <>' => '1',
			),
//			'limit' => 20,
//			'order' => array(
//			'Message.created' => 'desc'
//			),
		);
		$this->paginate = $option;
		$data = $this->paginate();
		
		$this->Shop->recursive = 0;
		$this->set('shops', $data);
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Shop', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('shop', $this->Shop->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Shop->create();
			if ($this->Shop->save($this->data)) {
				$this->Session->setFlash(__('The Shop has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Shop could not be saved. Please, try again.', true));
			}
		}
		$cities = $this->Shop->City->find('list');
		$this->set(compact('cities'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Shop', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Shop->save($this->data)) {
				$this->Session->setFlash(__('The Shop has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Shop could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Shop->read(null, $id);
		}
		$cities = $this->Shop->City->find('list');
		$this->set(compact('cities'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Shop', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Shop->del($id)) {
			$this->Session->setFlash(__('Shop deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Shop could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>