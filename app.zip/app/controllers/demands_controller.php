<?php
class DemandsController extends AppController {

	var $name = 'Demands';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth', 'Qdmail');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->allow('webAdd', 'productList');  
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Demand->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->Demand->recursive = 0;
		$this->set('demands', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Demand', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('demand', $this->Demand->read(null, $id));
	}

	function add() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');
		$staffId = $this->Auth->user('id');
		$staffName = $this->Auth->user('name');
		$staffNumber = $this->Auth->user('staff_number');
		$shopId = $this->Auth->user('shop_id');
		$staffShop = $this->Demand->getStaffShop($shopId);

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = 'add_main';
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = 'add_staff';
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = 'add_admin';
		}

		if (!empty($this->data)) {
			if ( $this->data['Demand']['mode'] == 'confirm') {
				$this->Demand->set($this->data);
				if( !$this->Demand->validates($this->Demand) ) {
					$this->validateErrors($this->Demand);
				} else {
					$this->set('data', $this->data);
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = 'add_main_confirm';
					} else if ( $userLevel == STAFF_USER ) {
						$viewTemplate = 'add_staff_confirm';
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = 'add_admin_confirm';
					}
				}
			} else if ( $this->data['Demand']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				$data = array (
					'Demand' => array (
						'shop_id' => $userShopId,
						'staff_id' => $staffId,
						'shop_name' => $staffShop['Shop']['name'],
						'staff_name' => $staffName,
						'subject' => $this->data['Demand']['subject'],
						'body' => $this->data['Demand']['body'],
						'delete_flg' => 0,
						'creator_id' => $staff_id,
						'updater_id' => $staff_id,
					)
				);
				$this->Demand->create();
				if ($this->Demand->save($data)) {
					$today = getdate();
					$mailBody = "システム改善依頼を承りました。\n\n";
					$mailBody .= "--送信者--\n";
					$mailBody .= "スタッフ番号：{$staffNumber}\n";
					$mailBody .= "スタッフ名：{$staffName}\n\n";
					$mailBody .= "--件名--\n{$this->data['Demand']['subject']}\n\n";
					$mailBody .= "--内容--\n{$this->data['Demand']['body']}\n\n";
					
					$this->Qdmail->to( TOMAIL, 'セルジオロッシML[五反田電子商事]' );
					$this->Qdmail->subject('システム改善依頼');
					$this->Qdmail->from( FROMMAIL , '五反田電子商事システム' );
					$this->Qdmail -> text( $mailBody );
					$this->Qdmail -> send();
				
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = 'add_main_register';
					} else if ( $userLevel == STAFF_USER ) {
						$viewTemplate = 'add_staff_register';
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = 'add_admin_register';
					}
				}
			}
		}
		$this->render( $viewTemplate );

	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Demand', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Demand->save($this->data)) {
				$this->Session->setFlash(__('The Demand has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Demand could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Demand->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Demand', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Demand->del($id)) {
			$this->Session->setFlash(__('Demand deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Demand could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>