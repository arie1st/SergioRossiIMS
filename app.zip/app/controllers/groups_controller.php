<?php
class GroupsController extends AppController {

	var $name = 'Groups';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->allow('groupList');
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
//		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->Group->recursive = 0;
		$this->set('groups', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Group', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('group', $this->Group->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Group->create();
			if ($this->Group->save($this->data)) {
				$this->Session->setFlash(__('The Group has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Group could not be saved. Please, try again.', true));
			}
		}
		$seasons = $this->Group->Season->find('list');
		$this->set(compact('seasons'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Group', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Group->save($this->data)) {
				$this->Session->setFlash(__('The Group has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Group could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Group->read(null, $id);
		}
		$seasons = $this->Group->Season->find('list');
		$this->set(compact('seasons'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Group', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Group->del($id)) {
			$this->Session->setFlash(__('Group deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Group could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}


	function groupList() {
		$this->autoRender = false;
		Configure::write('debug', 0);


		$cond = array(
			'Group.season_id' => array(1),
			'Group.delete_flg' => array(0),
			);
		$groups = $this->Group->find('all', array(
			'conditions' => $cond,
			'order' => array('Group.rank'),
		));
		
		foreach($groups as $group) {		
			$groupArray[] = array("id" => $group['Group']['id'],
									"name" => $group['Group']['name'],
									);
           
		}
		
		print json_encode($groupArray);
		/* end */
	}

}
?>