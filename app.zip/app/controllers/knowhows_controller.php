<?php
class KnowhowsController extends AppController {

	var $name = 'Knowhows';
//	var $uses = array('Staff');
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');
		
	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->allow('webAdd', 'knowhowList', 'productKnowhowList', 'productUnitKnowhowList');  
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');
		$staffId = $this->Auth->user('id');
		$staffName = $this->Auth->user('name');
		$shopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$option = array(
				'conditions' => array( 
				'Knowhow.send_shop_id' => array('2', '3'),
				'Knowhow.product_id' => array('0'),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
				),
				'limit' => 20,
				'order' => array(
				'Knowhow.created' => 'desc'
				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('knowhows', $data);

			$viewTemplate = 'index_main';
		} else if ( $userLevel == STAFF_USER ) {
			$option = array(
				'conditions' => array( 
				'Knowhow.send_shop_id' => array('1', '2'),
				'Knowhow.shop_id' => array('0', $userShopId),
				'Knowhow.product_id' => array('0'),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
				),
				'limit' => 20,
				'order' => array(
				'Knowhow.created' => 'desc'
				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('knowhows', $data);

			$viewTemplate = 'index_staff';
		} else if ( $userLevel == SYSTEM_USER ) {
			$this->Knowhow->recursive = 0;
			$this->set('knowhows', $this->paginate());

			$viewTemplate = 'index_admin';			
		}
		$this->render( $viewTemplate );
	}

	function productIndex() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');
		$staffId = $this->Auth->user('id');
		$staffName = $this->Auth->user('name');
		$shopId = $this->Auth->user('shop_id');

		$cond = array(
			'Staff.staff_number' => array( $this->data['Staff']['staff_number'] ),
			'Staff.password' => array( $this->data['Staff']['staff_password'] ),
		);
		$staff = $this->Knowhow->Staff->find('all', array(
			'conditions' => $cond
		));

		if ( $userLevel == HEAD_USER ) {
			$option = array(
				'conditions' => array( 
				'Knowhow.send_shop_id' => array('2', '3'),
				'NOT' => array('Knowhow.product_id' => 0),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
				),
				'limit' => 20,
				'order' => array(
				'Knowhow.created' => 'desc'
				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('knowhows', $data);

			$viewTemplate = 'product_index_main';
		} else if ( $userLevel == STAFF_USER ) {
			$option = array(
				'conditions' => array( 
				'Knowhow.send_shop_id' => array('1', '2'),
				'Knowhow.shop_id' => array('0', $userShopId),
				'NOT' => array('Knowhow.product_id' => 0),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
				),
				'limit' => 20,
				'order' => array(
				'Knowhow.created' => 'desc'
				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('knowhows', $data);

			$viewTemplate = 'product_index_staff';
		} else if ( $userLevel == SYSTEM_USER ) {
			$this->Knowhow->recursive = 0;
			$this->set('knowhows', $this->paginate());

			$viewTemplate = 'index_admin';			
		}
		$this->render( $viewTemplate );
	}

	//-- iPad用全ての接客ノウハウリストを取得
	function knowhowList() {
		$this->autoRender = false;
		Configure::write('debug', 0);
		
		$user = $this->params['named']['user'];
		$cond = array(
			'Staff.id' => array( $user ),
			);
		$staff = $this->Knowhow->Staff->find('first', array(
			'conditions' => $cond
		));
		$userShopId = $staff['Staff']['shop_id'];
		$userLevel = $staff['Staff']['level'];

		if ( $userLevel == HEAD_USER ) {
			$cond = array(
				'Knowhow.send_shop_id' => array('2', '3'),
				'Knowhow.product_id' => array('0'),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
			);
		} else if ( $userLevel == STAFF_USER ) {
			$cond = array(
				'Knowhow.send_shop_id' => array('1', '2'),
				'Knowhow.shop_id' => array('0', $userShopId),
				'Knowhow.product_id' => array('0'),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
			);
		}
		
		$knowhows = $this->Knowhow->find('all', array(
			'conditions' => $cond,
			'order' => array(
				'Knowhow.created' => 'DESC'
				)
			));

		printf('<?xml version="1.0"?>'."\n");
		printf("<knowhows>\n");
		foreach($knowhows as $knowhow) {
			printf("<knowhow id=\"%d\">\n", $knowhow['Knowhow']['id']);
			printf("<product id=\"%d\">%s</product>\n", $knowhow['Knowhow']['product_id'], $knowhow['Knowhow']['product_name']);
			printf("<subject>%s</subject>\n", $knowhow['Knowhow']['subject']);
			printf("<state>（%s）</state>\n", $knowhow['State']['name']);
			printf("<body>%s</body>\n", $knowhow['Knowhow']['body']);
			printf("<staffname>%s</staffname>\n", $knowhow['Knowhow']['staff_name']);
			printf("<created>%s</created>\n", $knowhow['Knowhow']['created']);
			printf("</knowhow>\n");
		}
		printf("</knowhows>\n");
	}

	//-- iPad用全ての商品ノウハウを取得
	function productKnowhowList() {
		$this->autoRender = false;
		Configure::write('debug', 0);
		
		$user = $this->params['named']['user'];
		$cond = array(
			'Staff.id' => array( $user ),
			);
		$staff = $this->Knowhow->Staff->find('first', array(
			'conditions' => $cond
		));
		$userShopId = $staff['Staff']['shop_id'];
		$userLevel = $staff['Staff']['level'];

		if ( $userLevel == HEAD_USER ) {
			$cond = array(
				'Knowhow.send_shop_id' => array('2', '3'),
				'NOT' => array('Knowhow.product_id' => 0),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
			);
		} else if ( $userLevel == STAFF_USER ) {
			$cond = array(
				'Knowhow.send_shop_id' => array('1', '2'),
				'Knowhow.shop_id' => array('0', $userShopId),
				'NOT' => array('Knowhow.product_id' => 0),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
			);
		}
				
		$knowhows = $this->Knowhow->find('all', array(
			'conditions' => $cond,
			'order' => array(
				'Knowhow.created' => 'DESC'
				)
			));

		printf('<?xml version="1.0"?>'."\n");
		printf("<knowhows>\n");
		foreach($knowhows as $knowhow) {
			printf("<knowhow id=\"%d\">\n", $knowhow['Knowhow']['id']);
			printf("<product id=\"%d\">%s</product>\n", $knowhow['Knowhow']['product_id'], $knowhow['Knowhow']['product_name']);
			printf("<subject>%s</subject>\n", $knowhow['Knowhow']['subject']);
			printf("<state>（%s）</state>\n", $knowhow['State']['name']);
			printf("<body>%s</body>\n", $knowhow['Knowhow']['body']);
			printf("<staffname>%s</staffname>\n", $knowhow['Knowhow']['staff_name']);
			printf("<created>%s</created>\n", $knowhow['Knowhow']['created']);
			printf("</knowhow>\n");
		}
		printf("</knowhows>\n");
	}

	//-- iPad用商品ノウハウリスト一覧
	function productUnitKnowhowList($id = null) {
		$this->autoRender = false;
		Configure::write('debug', 0);
		
		$user = $this->params['named']['user'];
		$cond = array(
			'Staff.id' => array( $user ),
			);
		$staff = $this->Knowhow->Staff->find('first', array(
			'conditions' => $cond
		));
		$userShopId = $staff['Staff']['shop_id'];
		$userLevel = $staff['Staff']['level'];

		if ( $userLevel == HEAD_USER ) {
			$cond = array(
				'Knowhow.send_shop_id' => array('2', '3'),
				'Knowhow.product_id' => array($id),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
			);
		} else if ( $userLevel == STAFF_USER ) {
			$cond = array(
				'Knowhow.send_shop_id' => array('1', '2'),
				'Knowhow.shop_id' => array('0', $userShopId),
				'Knowhow.product_id' => array($id),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				'Knowhow.delete_flg' => array('0'),
			);
		}
				
		$knowhows = $this->Knowhow->find('all', array(
			'conditions' => $cond,
			'order' => array(
				'Knowhow.created' => 'DESC'
				)
			));

		printf('<?xml version="1.0"?>'."\n");
		printf("<knowhows>\n");
		foreach($knowhows as $knowhow) {
			printf("<knowhow id=\"%d\">\n", $knowhow['Knowhow']['id']);
			printf("<product id=\"%d\">%s</product>\n", $knowhow['Knowhow']['product_id'], $knowhow['Knowhow']['product_name']);
			printf("<subject>%s</subject>\n", $knowhow['Knowhow']['subject']);
			printf("<state>（%s）</state>\n", $knowhow['State']['name']);
			printf("<body>%s</body>\n", $knowhow['Knowhow']['body']);
			printf("<staffname>%s</staffname>\n", $knowhow['Knowhow']['staff_name']);
			printf("<created>%s</created>\n", $knowhow['Knowhow']['created']);
			printf("</knowhow>\n");
		}
		printf("</knowhows>\n");
	}

	function registerList() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = 'register_list_main';
		} else if ( $userLevel == STAFF_USER ) {		
			$option = array(
				'conditions' => array(
				'Knowhow.shop_id' => array($userShopId),
				),
				'limit' => 20,
				'order' => array(
				'Knowhow.created' => 'desc'
				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('knowhows', $data);
			
			$viewTemplate = 'register_list_staff';
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = 'register_list_admin';			
		}
				
		$this->render( $viewTemplate );
	}


	function approval($id = null) {
		$userLevel = $this->Auth->user('level');
		$staff_id = $this->Auth->user('id');
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Knowhow', true));
			$this->redirect(array('action' => 'index'));
		}
		$data = array (
			'Knowhow' => array (
			'id' => $id,
			'approval_flg' => 1,
			'updater_id' => $staff_id,
			)
		);
		if ($this->Knowhow->save($data)) {
			$this->Session->setFlash(__('Knowhow deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Knowhow could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));

	}
	
	function unapproval($id = null) {
		$userLevel = $this->Auth->user('level');
		$staff_id = $this->Auth->user('id');
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Knowhow', true));
			$this->redirect(array('action' => 'index'));
		}
		$data = array (
			'Knowhow' => array (
			'id' => $id,
			'approval_flg' => 2,
			'updater_id' => $staff_id,
			)
		);
		if ($this->Knowhow->save($data)) {
			$this->Session->setFlash(__('Knowhow deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Knowhow could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));

	}

	
	function unapprovalList() {
		$userLevel = $this->Auth->user('level');
		
		if (!empty($this->data)) {
			if ( $this->data['Knowhow']['mode'] == 'update') {
				if ( $userLevel == 1 ) {
					$viewTemplate = 'unapproval_list_main';
				} else if ( $userLevel == 2 ) {
					$viewTemplate = 'index_staff';
				} else if ( $userLevel == 9 ) {
					$viewTemplate = 'index_admin';
				}
				
				foreach ($this->data['Knowhow'] as $line) {	
					$data = array (
						'Knowhow' => array (
						'id' => $line['id'],
						'approval_flg' => 1,
						)
					);
					$this->Knowhow->save($data);
				}
				
				print_r($this->data);
			}
		} else {
			if ( $userLevel == 1 ) {
				$viewTemplate = 'unapproval_list_main';
			} else if ( $userLevel == 2 ) {
				$viewTemplate = 'index_staff';
			} else if ( $userLevel == 9 ) {
				$viewTemplate = 'index_admin';
			}
		}

		$cond = array('Knowhow.approval_flg' => '0');
		$knowhows = $this->Knowhow->find('all', array(
			'conditions' => $cond,
			'order' => array(
			'Knowhow.created' => 'desc'
			),
		));
		$this->Knowhow->recursive = 0;
		$this->set('knowhows', $knowhows);

		$this->render( $viewTemplate );			
	}


	function unapprovalUpdate() {
		$userLevel = $this->Auth->user('level');
		if ( $userLevel == 1 ) {
			$viewTemplate = 'unapproval_update_main';
		} else if ( $userLevel == 2 ) {
			$viewTemplate = 'unapproval_update_staff';
		} else if ( $userLevel == 9 ) {
			$viewTemplate = 'unapproval_update_admin';
		}

		if (!empty($this->data)) {
			if ( $userLevel == 1 ) {
				$viewTemplate = 'unapproval_update_main';
			} else if ( $userLevel == 2 ) {
				$viewTemplate = 'unapproval_update_staff';
			} else if ( $userLevel == 9 ) {
				$viewTemplate = 'unapproval_update_admin';
			}
				
			foreach ($this->data['Knowhow'] as $line) {	
				$data = array (
					'Knowhow' => array (
					'id' => $line['id'],
					'approve_flg' => 1,
					)
				);
				$this->Knowhow->save($data);
			}
		} else {
			$this->redirect(array('action' => 'index'));
		}
		$this->render( $viewTemplate );	
	}

	function view($id = null) {
		$userLevel = $this->Auth->user('level');
		if (!$id) {
			$this->Session->setFlash(__('Invalid Knowhow', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('knowhow', $this->Knowhow->read(null, $id));
		if ( $userLevel == 1 ) {
			$this->render("view_main");
		} else if ( $userLevel == 2 ) {
			$this->render("view_staff");
		} else if ( $userLevel == 9 ) {
			$this->render("view_admin");			
		}
	}

	function add() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');
		$staffId = $this->Auth->user('id');
		$staffName = $this->Auth->user('name');
		$shopId = $this->Auth->user('shop_id');
		$staffShop = $this->Knowhow->getStaffShop($shopId);

		if (!empty($this->data)) {
			if ( $this->data['Knowhow']['mode'] == 'confirm') {
				$this->Knowhow->set($this->data);
				if( !$this->Knowhow->validates($this->Knowhow) ) {
					$this->validateErrors($this->Knowhow);
					
					$staffs = $this->Knowhow->Staff->find('list');
					$this->set(compact('staffs'));
			
					$cond = array('SendShop.delete_flg' => '0');
					$sendShops = $this->Knowhow->SendShop->find('list', array(
						'conditions' => $cond,
					));
					$this->set(compact('sendShops'));
			
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = "add_main";
					} else if ( $userLevel == STAFF_USER ) {
						$viewTemplate = "add_staff";
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = "add_admin";
					}
				} else {
					$this->set('data', $this->data);
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = "add_main_confirm";
					} else if ( $userLevel == STAFF_USER ) {
						$viewTemplate = "add_staff_confirm";
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = "add_admin_confirm";
					}
				}
			} else if ( $this->data['Knowhow']['mode'] == 'regsister' ) {

				if ( $this->data['Knowhow']['send_shop_id'] == 2 ) {
					$shopId = 0;
				}
				$data = array (
					'Knowhow' => array (
						'state_id' => $this->data['Knowhow']['state_id'],
						'send_shop_id' => $this->data['Knowhow']['send_shop_id'],
						'shop_id' => $shopId,
						'staff_id' => $staffId,
						'shop_name' => $staffShop['Shop']['name'],
						'staff_name' => $staffName,
//						'product_id' => $this->data['Knowhow']['product_id'],
//						'product_name' => $this->data['Knowhow']['product_name'],
						'subject' => $this->data['Knowhow']['subject'],
						'body' => $this->data['Knowhow']['body'],
						'approval_flg' => 1,
						'delete_flg' => 0,
						'creator_id' => $staffId,
						'updater_id' => $staffId,
					)
				);

				$this->Knowhow->create();
				if ($this->Knowhow->save($data)) {
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = "add_main_register";
					} else if ( $userLevel == STAFF_USER ) {
						$viewTemplate = "add_staff_register";
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = "add_admin_register";
					}
				}
			}
		} else {
			$staffs = $this->Knowhow->Staff->find('list');
			$this->set(compact('staffs'));
						
			$sendShops = $this->Knowhow->SendShop->find('list');
			$this->set(compact('sendShops'));
			
			$states = $this->Knowhow->State->find('list');
			$this->set(compact('states'));

			if ( $userLevel == HEAD_USER ) {
				$viewTemplate = "add_main";
			} else if ( $userLevel == STAFF_USER ) {
				$viewTemplate = "add_staff";
			} else if ( $userLevel == SYSTEM_USER ) {
				$viewTemplate = "add_admin";
			}
		}
		$this->render($viewTemplate);
	}


	function webAdd() {
		$this->autoRender = false;
		Configure::write('debug', 0);

		if (!empty($this->data)) {
			$cond = array(
				'Staff.staff_number' => array( $this->data['Staff']['staff_number'] ),
				'Staff.password' => array( $this->data['Staff']['staff_password'] ),
				);
			$staff = $this->Knowhow->Staff->find('all', array(
				'conditions' => $cond
			));

			if ( count($staff) != 0 ) {
				$shopId = $this->data['Knowhow']['shop_id'];
				if ( $this->data['Knowhow']['send_shop_id'] == 2 ) {
					$shopId = 0;
				}

				$data = array (
					'Knowhow' => array (
						'state_id' => $this->data['Knowhow']['state_id'],
						'send_shop_id' => $this->data['Knowhow']['send_shop_id'],
						'shop_id' => $shopId,
						'staff_id' => $this->data['Knowhow']['staff_id'],
						'shop_name' => $this->data['Knowhow']['shop_name'],
						'staff_name' => $this->data['Knowhow']['staff_name'],
						'product_id' => $this->data['Knowhow']['product_id'],
						'product_name' => $this->data['Knowhow']['product_name'],
						'subject' => $this->data['Knowhow']['subject'],
						'body' => $this->data['Knowhow']['body'],
						'approval_flg' => 1,
						'delete_flg' => 0,
						'creator_id' => $this->data['Knowhow']['staff_id'],
						'updater_id' => $this->data['Knowhow']['staff_id'],
					)
				);

				$this->Knowhow->create();
				if ($this->Knowhow->save($data)) {
					echo '1';
				} else {
					echo '0';
				}
			} else {
					echo '0';
			}
		}
	}

	function edit($id = null) {
		$userLevel = $this->Auth->user('level');
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Knowhow', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
		
			if ( $this->data['Knowhow']['mode'] == 'confirm') {
				$this->Knowhow->set($this->data);
				if( !$this->Knowhow->validates($this->Knowhow) ) {
					$this->validateErrors($this->Knowhow);
				} else {
					$this->set('data', $this->data);
					if ( $userLevel == 1 ) {
						$this->render("edit_main_confirm");
					} else if ( $userLevel == 2 ) {
						$this->render("edit_staff_confirm");
					} else if ( $userLevel == 9 ) {
						$this->render("edit_admin_confirm");			
					}
				}
			} else if ( $this->data['Knowhow']['mode'] == 'regsister' ) {
				$staffId = $this->Auth->user('id');
				$staffName = $this->Auth->user('name');
				$shopId = $this->Auth->user('shop_id');
				$staffShop = $this->Knowhow->getStaffShop($shopId);
				$data = array (
					'Knowhow' => array (
						'id' => $id,
						'shop_id' => $shopId,
						'shop_name' => $staffShop['Shop']['name'],
						'staff_id' => $staffId,
						'staff_name' => $staffName,
//						'product_id' => $this->data['Knowhow']['product_id'],
//						'product_name' => $this->data['Knowhow']['product_name'],
						'subject' => $this->data['Knowhow']['subject'],
						'body' => $this->data['Knowhow']['body'],
//						'approval_flg' => 0,
//						'delete_flg' => 0,
//						'creator_id' => $staffId,
						'updater_id' => $staffId,
					)
				);
				if ($this->Knowhow->save($data)) {
					if ( $userLevel == 1 ) {
						$this->render("edit_main_register");
					} else if ( $userLevel == 2 ) {
						$this->render("edit_staff_register");
					} else if ( $userLevel == 9 ) {
						$this->render("edit_admin_register");			
					}
				}
			}
		} else {
			if (empty($this->data)) {
				$this->data = $this->Knowhow->read(null, $id);
			}

			if ( $userLevel == 1 ) {
				$this->render("edit_main");
			} else if ( $userLevel == 2 ) {
				$this->render("edit_staff");
			} else if ( $userLevel == 9 ) {
				$this->render("edit_admin");
			}	
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Knowhow', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Knowhow->del($id)) {
			$this->Session->setFlash(__('Knowhow deleted', true));
			$this->redirect(array('action' => 'registerList'));
		}
		$this->Session->setFlash(__('The Knowhow could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

	function deleteUpdate($id = null) {
//		if ( $this->data['Knowhow']['mode'] == 'regsister' ) {
			$staffId = $this->Auth->user('id');
			$staffName = $this->Auth->user('name');
			$shopId = $this->Auth->user('shop_id');
			$staffShop = $this->Knowhow->getStaffShop($shopId);
			$data = array (
				'Knowhow' => array (
					'id' => $id,
					'delete_flg' => 1,
					'updater_id' => $staffId,
				)
			);
			if ($this->Knowhow->save($data)) {
//				if ( $userLevel == 1 ) {
//					$this->render("edit_main_register");
//				} else if ( $userLevel == 2 ) {
//					$this->render("edit_staff_register");
//				} else if ( $userLevel == 9 ) {
//					$this->Session->setFlash(__('Knowhow deleted', true));
					$this->redirect(array('action' => 'index'));
//				}
			}
//		}
	}
	
	function approval2($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Knowhow', true));
			$this->redirect(array('action' => 'index'));
		}
		
		$staff_id = $this->Auth->user('id');
		$data = array (
			'Knowhow' => array (
				'id' => $id,
				'approval_flg' => 1,
				'updater_id' => $staff_id,
			)
		);
		if ($this->Knowhow->save($data)) {
			$this->Session->setFlash(__('Knowhow Approved', true));
			$this->redirect(array('action' => 'index'));
		}
		
		$this->Session->setFlash(__('The Knowhow could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}
	

	function ranking($searchDate = null) {
		$userLevel = $this->Auth->user('level');

		if (!$searchDate) {
			$searchDay = date("Y-m-d", strtotime("-1 day"));
			$searchMonth = date("Y-m");
		} else {
			$searchDay = date("Y-m-d", strtotime($searchDate));
			$searchMonth = date("Y-m", strtotime($searchDate));		
		}

		$shopResults = $this->Knowhow->query("SELECT 
			`Knowhow`.`shop_id`, `Knowhow`.`shop_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`shop_id`, `Knowhow`.`shop_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($shopResults as $key => $row) {
			if (!empty($row[0]['created'])) {
				$shopResults[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($shopResults[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$shopResults[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($shopResults[$key][0]['count']);
			}
		}
		$this->set('shopRanking', $shopResults);
		
		//--
		$staffResults = $this->Knowhow->query("SELECT 
			`Knowhow`.`shop_id`, `Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`shop_id`, `Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($staffResults as $key => $row) {
			if (!empty($row[0]['created'])) {
				$staffResults[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($staffResults[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$staffResults[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($staffResults[$key][0]['count']);
			}
		}
		$this->set('staffRanking', $staffResults);

		$productResults = $this->Knowhow->query("SELECT 
			`Knowhow`.`product_id`, `Knowhow`.`product_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' AND `Knowhow`.`product_id`<>0 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`product_id`, `Knowhow`.`product_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($productResults as $key => $row) {
			if (!empty($row[0]['created'])) {
				$productResults[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($productResults[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$productResults[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($productResults[$key][0]['count']);
			}
		}
		$this->set('productRanking', $productResults);

		
		if ( $userLevel == 1 ) {
			$this->render("ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}


	function shopDayRanking($searchDay = null) {
		$userLevel = $this->Auth->user('level');
		
		if (!$searchDay) {
			$searchDay = date("Y-m-d", strtotime("-1 day"));
		}
		
		$results = $this->Knowhow->query("SELECT 
			`Knowhow`.`shop_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`shop_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($results as $key => $row) {
			if (!empty($row[0]['created'])) {
				$results[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($results[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$results[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($results[$key][0]['count']);
			}
		}

		$this->set('searchDay', $searchDay);		
		$this->set('knowhows', $results);
		
		if ( $userLevel == 1 ) {
			$this->render("shop_day_ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("shop_day_ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}
		
	
	function shopMonthRanking($searchMonth = null) {
		$userLevel = $this->Auth->user('level');

		if (!$searchMonth) {
			$searchMonth = date("Y-m");
		} else {
			$searchMonth = date("Y-m", strtotime($searchMonth));		
		}

		$results = $this->Knowhow->query("SELECT 
			`Knowhow`.`shop_name`, DATE_FORMAT(created,'%Y-%m') AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE DATE_FORMAT(created,'%Y-%m') = '$searchMonth' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`shop_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($results as $key => $row) {
			if (!empty($row[0]['created'])) {
				$results[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($results[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$results[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($results[$key][0]['count']);
			}
		}

		$this->set('searchMonth', $searchMonth);		
		$this->set('knowhows', $results);
		
		if ( $userLevel == 1 ) {
			$this->render("shop_month_ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("shop_month_ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}

	
	function staffDayRanking($searchDay = null) {
		$userLevel = $this->Auth->user('level');
		
		if (!$searchDay) {
			$searchDay = date("Y-m-d", strtotime("-1 day"));
		}
		
		$results = $this->Knowhow->query("SELECT 
			`Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($results as $key => $row) {
			if (!empty($row[0]['created'])) {
				$results[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($results[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$results[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($results[$key][0]['count']);
			}
		}

		$this->set('searchDay', $searchDay);
		$this->set('knowhows', $results);
		
		if ( $userLevel == 1 ) {
			$this->render("staff_day_ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("staff_day_ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}
	
	
	function staffMonthRanking($searchMonth = null) {
		$userLevel = $this->Auth->user('level');

		if (!$searchMonth) {
			$searchMonth = date("Y-m");
		} else {
			$searchMonth = date("Y-m", strtotime($searchMonth));		
		}

		$results = $this->Knowhow->query("SELECT 
			`Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`, DATE_FORMAT(created,'%Y-%m') AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE DATE_FORMAT(created,'%Y-%m') = '$searchMonth' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($results as $key => $row) {
			if (!empty($row[0]['created'])) {
				$results[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($results[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$results[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($results[$key][0]['count']);
			}
		}
		
		$this->set('searchMonth', $searchMonth);
		$this->set('knowhows', $results);

		if ( $userLevel == 1 ) {
			$this->render("staff_month_ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("staff_month_ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}

	
	function productDayRanking($searchDay = null) {
		$userLevel = $this->Auth->user('level');
		
		if (!$searchDay) {
			$searchDay = date("Y-m-d", strtotime("-1 day"));
		}
		
		$results = $this->Knowhow->query("SELECT 
			`Knowhow`.`product_id`, `Knowhow`.`product_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' AND `Knowhow`.`product_id`<>0 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`product_id`, `Knowhow`.`product_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($results as $key => $row) {
			if (!empty($row[0]['created'])) {
				$results[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($results[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$results[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($results[$key][0]['count']);
			}
		}

		$this->set('searchDay', $searchDay);
		$this->set('knowhows', $results);
		
		if ( $userLevel == 1 ) {
			$this->render("product_day_ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("product_day_ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}
	
	
	function productMonthRanking($searchMonth = null) {
		$userLevel = $this->Auth->user('level');

		if (!$searchMonth) {
			$searchMonth = date("Y-m");
		} else {
			$searchMonth = date("Y-m", strtotime($searchMonth));		
		}

		$results = $this->Knowhow->query("SELECT 
			`Knowhow`.`product_id`, `Knowhow`.`product_name`, DATE_FORMAT(created,'%Y-%m') AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE DATE_FORMAT(created,'%Y-%m') = '$searchMonth' 
			AND `Knowhow`.`delete_flg` = '0' 
			GROUP BY `Knowhow`.`product_id`, `Knowhow`.`product_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($results as $key => $row) {
			if (!empty($row[0]['created'])) {
				$results[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($results[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$results[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($results[$key][0]['count']);
			}
		}
		
		$this->set('searchMonth', $searchMonth);
		$this->set('knowhows', $results);

		if ( $userLevel == 1 ) {
			$this->render("product_month_ranking_main");
		} else if ( $userLevel == 2 ) {
			$this->render("product_month_ranking_staff");
		} else if ( $userLevel == 9 ) {
		}
	}


/*

//-- 日別店舗ランキング
SELECT 
shop_id, shop_name, date(created) AS created_date, count(id) 
FROM knowhows
GROUP BY shop_id, shop_name, created_date
ORDER BY count(id) DESC

//--日別スタッフランキング
SELECT 
shop_id, staff_id, shop_name, staff_name, date(created) AS created_date, count(id) 
FROM knowhows 
GROUP BY shop_id, staff_id, shop_name, staff_name, created_date
ORDER BY count(id) DESC;

//-- 日別商品ランキング
SELECT 
product_id, date(created) AS created_date, count(id) 
FROM knowhows 
WHERE product_id!=0 AND product_id!=999999
GROUP BY product_id, created_date
ORDER BY count(id) DESC;

集計
SELECT 
product_id, DATE_FORMAT(created,'%Y-%m-%d') as created_date, count(id) 
FROM knowhows 
WHERE product_id!=0 AND product_id!=999999
AND DATE_FORMAT(created,'%Y-%m-%d')='2010-12-03'
GROUP BY product_id, created_date
ORDER BY count(id) DESC;

*/
}
?>