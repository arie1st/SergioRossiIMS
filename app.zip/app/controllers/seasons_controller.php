<?php
class SeasonsController extends AppController {

	var $name = 'Seasons';
	var $uses = array('Season', 'Content', 'MenuTitle','Category', 'Group', 'Color', 'Price', 'ProductColorChip', 'PastCollection', 'Clipping');
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->allow('appData', 'seasonData');
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Season->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->Season->recursive = 0;
		$this->set('seasons', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Season', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('season', $this->Season->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Season->create();
			if ($this->Season->save($this->data)) {
				$this->Session->setFlash(__('The Season has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Season could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Season', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Season->save($this->data)) {
				$this->Session->setFlash(__('The Season has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Season could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Season->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Season', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Season->del($id)) {
			$this->Session->setFlash(__('Season deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Season could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}


	function appData() {
		$this->autoRender = false;
		Configure::write('debug', 0);

		$cond = array(
			'Season.main_flg' => array(1),
			'Season.delete_flg' => array(0),
			);
		$seasonMain = $this->Season->find('all', array(
			'conditions' => $cond,
		));
	
		foreach($seasonMain as $season){
			$mainSeason = $season['Season']['key'];
		}
		
		
		/* Season Data*/
		$cond = array(
			'Season.delete_flg' => array(0),
			);
		$seasons = $this->Season->find('all', array(
			'conditions' => $cond,
		));
		
		foreach($seasons as $season){
			$seasonArray[] = array("id" => $season['Season']['id'],
									"name" => $season['Season']['name'],
									"key" => $season['Season']['key'],
									"sqlite" => $season['Season']['sqlite'],
									);
		}
		
		
		/* PastCollection Data */
		$cond = array(
			'PastCollection.delete_flg' => array(0),
			);
		$pastCollections = $this->PastCollection->find('all', array(
			'conditions' => $cond,
			'order' => array('PastCollection.rank'),
		));
		
		foreach($pastCollections as $pastCollection){
			$pastCollectionArray[] = array("id" => $pastCollection['PastCollection']['id'],
										"season_id" => $pastCollection['PastCollection']['season_id'],
										"name" => $pastCollection['PastCollection']['name'],
										"key" => $pastCollection['PastCollection']['key'],
										"contenttype" => $pastCollection['PastCollection']['contenttype'],
										"filename" => $pastCollection['PastCollection']['filename'],
										);
		};
		

		/* Comimuinication - Celebrity */
		$celebrityArray = array();
/*
		$celebrityArray = array(array("id" => 1,
									"thumbnail" => "",
									"filename" => "Katy-Perry.jpg",
									"name" => "Katy Perry",
									"text" => "Blue patent platform slingbacks, 'CACHET'",
								),
						array("id" => 2,
									"thumbnail" => "",
									"filename" => "Anne-Hathaway.jpg",
									"name" => "Anne Hathaway",
									"text" => "Nude patent platform slingbacks, 'CACHET'",
								),
						array("id" => 3,
									"thumbnail" => "",
									"filename" => "kate-bosworth.jpg",
									"name" => "Kate Bosworth",
									"text" => "Black suede pumps with leopard detail, 'CHICHI'",
								),
					
						array("id" => 4,
									"thumbnail" => "",
									"filename" => "Hilary-Swank.jpg",
									"name" => "Hilary Swank",
									"text" => "Blue gladiator sandals, 'Boder line'",
								),
						array("id" => 5,
									"thumbnail" => "",
									"filename" => "Eva-Riccobono.jpg",
									"name" => "Eva Riccobono",
									"text" => "Gold sequined satin gladiator sandals, 'ECAILLER'",
								),
						array("id" => 6,
									"thumbnail" => "",
									"filename" => "Katy-Saunders.jpg",
									"name" => "Katy Saunders",
									"text" => "Black slingback peep-toe platform pumps, 'CACHET'",
								),
						array("id" => 7,
									"thumbnail" => "",
									"filename" => "Kristen-Stewart.jpg",
									"name" => "Kristen Stewart",
									"text" => "Black embossed leather lace-up ankle booties, 'GSTAD'",
								),
						array("id" => 8,
									"thumbnail" => "",
									"filename" => "Mischa-Barton.jpg",
									"name" => "Mischa Barton",
									"text" => "Grey suede and crystal cage platform sandals, 'VAGUE'",
								),
						array("id" => 9,
									"thumbnail" => "",
									"filename" => "Marion-Cotillard.jpg",
									"name" => "Marion Cotillard",
									"text" => "Black leather platform pump, 'CACHET'",
								),
							);
*/
		/* Comimuinication - Clippings */
		$cond = array(
			'Clipping.delete_flg' => array(0),
			);
		$clippings = $this->Clipping->find('all', array(
			'conditions' => $cond,
			'order' => array('Clipping.rank'),
		));

		foreach($clippings as $clipping){
			$clippingsArray[] = array("id" => $clipping['Clipping']['id'],
										"thumbnail" => $clipping['Clipping']['thumbnail'],
										"filename" => $clipping['Clipping']['filename'],
										"name" => $clipping['Clipping']['name'],
										"text" => $clipping['Clipping']['text'],
										);
		};

/*
		$clippingsArray = array(array("id" => 1,
										"thumbnail" => "1_S.jpg",
										"filename" => "1_L.jpg",
										"name" => "",
										"text" => "Grazia\nMarch\n1-Feb\n33",
										),
								array("id" => 2,
										"thumbnail" => "2_S.jpg",
										"filename" => "2_L.jpg",
										"name" => "",
										"text" => "Grazia\nMarch\n1-Feb\n50",
										),
								array("id" => 3,
										"thumbnail" => "3_S.jpg",
										"filename" => "3_L.jpg",
										"name" => "",
										"text" => "KATEI GAHO\nMarch\n1-Feb\n133",
										),
								array("id" => 4,
										"thumbnail" => "4_S.jpg",
										"filename" => "4_L.jpg",
										"name" => "",
										"text" => "KATEI GAHO\nMarch\n1-Feb\n135",
										),
								array("id" => 5,
										"thumbnail" => "5_S.jpg",
										"filename" => "5_L.jpg",
										"name" => "",
										"text" => "KATEI GAHO\nMarch\n1-Feb\n172",
										),
								array("id" => 6,
										"thumbnail" => "6_S.jpg",
										"filename" => "6_L.jpg",
										"name" => "",
										"text" => "STORY\nMarch\n1-Feb\n79",
										),
										
								array("id" => 7,
										"thumbnail" => "7_S.jpg",
										"filename" => "7_L.jpg",
										"name" => "",
										"text" => "Ane can\nMarch\n7-Feb\n106",
										),
								array("id" => 8,
										"thumbnail" => "8_S.jpg",
										"filename" => "8_L.jpg",
										"name" => "",
										"text" => "GLAMOROUS\nMarch\n7-Feb\n79",
										),
										
								array("id" => 9,
										"thumbnail" => "9_S.jpg",
										"filename" => "9_L.jpg",
										"name" => "",
										"text" => "honeyee.com\nweb\n7-Feb\nhttp://www.honeyee.com/",
										),
								array("id" => 10,
										"thumbnail" => "10_S.jpg",
										"filename" => "10_L.jpg",
										"name" => "",
										"text" => "MRSMarch\n7-Feb\n79",
										),
								array("id" => 11,
										"thumbnail" => "11_S.jpg",
										"filename" => "11_L.jpg",
										"name" => "",
										"text" => "Precious\nMarch\n7-Feb\nCOVER",
										),
								array("id" => 12,
										"thumbnail" => "12_S.jpg",
										"filename" => "12_L.jpg",
										"name" => "",
										"text" => "Precious\nMarch\n7-Feb\n51",
										),
								array("id" => 13,
										"thumbnail" => "13_S.jpg",
										"filename" => "13_L.jpg",
										"name" => "",
										"text" => "Precious\nMarch\n7-Feb\n75",
										),
								array("id" => 14,
										"thumbnail" => "14_S.jpg",
										"filename" => "14_L.jpg",
										"name" => "",
										"text" => "Precious\nMarch\n7-Feb\n83",
										),
								array("id" => 15,
										"thumbnail" => "15_S.jpg",
										"filename" => "15_L.jpg",
										"name" => "",
										"text" => "Precious\nMarch\n7-Feb\n136",
										),
								array("id" => 16,
										"thumbnail" => "16_S.jpg",
										"filename" => "16_L.jpg",
										"name" => "",
										"text" => "ELLE ONLINE\nweb\n10-Feb\nhttp://www.elle.co.jp/",
										),
								array("id" => 17,
										"thumbnail" => "17_S.jpg",
										"filename" => "17_L.jpg",
										"name" => "",
										"text" => "HERSMay\n12-Feb\n71",
										),
								array("id" => 18,
										"thumbnail" => "18_S.jpg",
										"filename" => "18_L.jpg",
										"name" => "",
										"text" => "croissant premiumApril\n19-Feb\n88",
										),
								array("id" => 19,
										"thumbnail" => "19_S.jpg",
										"filename" => "19_L.jpg",
										"name" => "",
										"text" => "FIGARO japon\nApril\n20-Feb\n88",
										),
								array("id" => 20,
										"thumbnail" => "20_S.jpg",
										"filename" => "20_L.jpg",
										"name" => "",
										"text" => "FIGARO japon\nApril\n20-Feb\n106",
										),
								array("id" => 21,
										"thumbnail" => "21_S.jpg",
										"filename" => "21_L.jpg",
										"name" => "",
										"text" => "FIGARO japon\nApril\n20-Feb\n\n107",
										),
								array("id" => 22,
										"thumbnail" => "22_S.jpg",
										"filename" => "22_L.jpg",
										"name" => "",
										"text" => "LEON\nApril\n24-Feb\n102",
										),
								array("id" => 23,
										"thumbnail" => "23_S.jpg",
										"filename" => "23_L.jpg",
										"name" => "",
										"text" => "LEON\nApril\n24-Feb\n164",
										),
								array("id" => 24,
										"thumbnail" => "24_S.jpg",
										"filename" => "24_L.jpg",
										"name" => "",
										"text" => "25ans\nApril\n28-Feb\n83",
										),
								array("id" => 25,
										"thumbnail" => "25_S.jpg",
										"filename" => "25_L.jpg",
										"name" => "",
										"text" => "25ans\nApril\n28-Feb\n84",
										),
								array("id" => 26,
										"thumbnail" => "26_S.jpg",
										"filename" => "26_L.jpg",
										"name" => "",
										"text" => "25ans\nApril\n28-Feb\n90",
										),
								array("id" => 27,
										"thumbnail" => "27_S.jpg",
										"filename" => "27_L.jpg",
										"name" => "",
										"text" => "25ans\nApril\n28-Feb\n100",
										),
								array("id" => 28,
										"thumbnail" => "28_S.jpg",
										"filename" => "28_L.jpg",
										"name" => "",
										"text" => "VOGUE NIPPON\nApril\n28-Feb\n170",
										),
								array("id" => 29,
										"thumbnail" => "29_S.jpg",
										"filename" => "29_L.jpg",
										"name" => "",
										"text" => "VOGUE NIPPON\nApril\n28-Feb\n181",
										),
								array("id" => 30,
										"thumbnail" => "30_S.jpg",
										"filename" => "30_L.jpg",
										"name" => "",
										"text" => "VOGUE NIPPON\nApril\n28-Feb\n24(supplement)",
										),
								array("id" => 31,
										"thumbnail" => "31_S.jpg",
										"filename" => "31_L.jpg",
										"name" => "",
										"text" => "VOGUE NIPPON\nApril\n28-Feb\n25(supplement)",
										),
								array("id" => 32,
										"thumbnail" => "32_S.jpg",
										"filename" => "32_L.jpg",
										"name" => "",
										"text" => "With\nApril\n28-Feb\n57",
										),
							);
*/
		$boutiquesAndCorners = array(array("id" => 1,
											"contenttype" => "pdf",
											"name" => "BoutiquesAndCorners",
											"filename" => "BoutiquesAndCorners.pdf",
											),
									);
		$projectArray = array(array("id" => 1,
											"contenttype" => "pdf",
											"name" => "Project",
											"filename" => "MTOfixdata.pdf",
											),
									);

		$arr = array("MainSeason" => $mainSeason,
					"Season" => $seasonArray,
					"Celebrity" => $celebrityArray,
					"Clippings" => $clippingsArray,
					"PastCollection" => $pastCollectionArray,
					"BoutiquesAndCorners" => $boutiquesAndCorners,	
					"Project" => $projectArray,
					);
		
		print json_encode($arr);

	}


	function seasonData() {
		$this->autoRender = false;
		Configure::write('debug', 0);

		$cond = array(
			'Season.delete_flg' => array(0),
			);
		$seasons = $this->Season->find('all', array(
			'conditions' => $cond,
		));
	
		$ccc = array();
		foreach($seasons as $season){

			/* コンテンツデータ */
			$cond = array(
				'Content.season_id' => array($season['Season']['id']),
				);
			$contents = $this->Content->find('all', array(
				'conditions' => $cond,
			));			
			$contentArray = array();
			foreach($contents as $content){
				$contentArray[] = array("menu_id" => $content['Content']['menu_id'], 
										"filename" => $content['Content']['filename'], 
										"filetype" => $content['Content']['filetype']);
			}
			/* end */

			/* メニューデータ */
			$cond = array(
				'MenuTitle.season_id' => array($season['Season']['id']),
				'MenuTitle.delete_flg' => array(0),
				);
			$menuTitles = $this->MenuTitle->find('all', array(
				'conditions' => $cond,
				'order' => array('MenuTitle.menu_id', 'MenuTitle.rank'),
			));			
			$menuTitleArray = array();
			foreach($menuTitles as $menuTitle){
				$menuTitleArray[] = array("id" => $menuTitle['MenuTitle']['id'], 
										"menu_id" => $menuTitle['MenuTitle']['menu_id'], 
										"name" => $menuTitle['MenuTitle']['name'],
										"key" => $menuTitle['MenuTitle']['key'],
										"price_flg" => $menuTitle['MenuTitle']['price_flg'],
										);
			}
			/* end */
			
			/* カテゴリデータ */
			$cond = array(
				'Category.season_id' => array($season['Season']['id']),
				'Category.delete_flg' => array(0),
				);
			$categories = $this->Category->find('all', array(
				'conditions' => $cond,
				'order' => array('Category.menu_id', 'Category.name'),
			));			
			$categoryArray = array();
			foreach($categories as $category){
				$categoryArray[] = array("id" => $category['Category']['id'], 
										"menu_id" => $category['Category']['menu_id'], 
										"name" => $category['Category']['name'],
										);
			}
			/* end */

			/* グループデータ */
			$cond = array(
				'Group.season_id' => array($season['Season']['id']),
				'Group.delete_flg' => array(0),
				);
			$groups = $this->Group->find('all', array(
				'conditions' => $cond,
				'order' => array('Group.menu_id', 'Group.name'),
			));			
			$groupArray = array();
			foreach($groups as $group){
				$groupArray[] = array("id" => $group['Group']['id'], 
									"menu_id" => $group['Group']['menu_id'], 
									"name" => $group['Group']['name'],
									);
			}
			/* end */

			/* カラーデータ */
			$cond = array(
				'Color.season_id' => array($season['Season']['id']),
				'Color.menu_id' => array(1),
				'Color.delete_flg' => array(0),
				);
			$colors = $this->Color->find('all', array(
				'conditions' => $cond,
				'order' => array('Color.menu_id', 'Color.rank'),
			));
			$colorArray = array();
			foreach($colors as $color) {
				$colorArray[] = array("id" => $color['Color']['id'], 
							"menu_id" => $color['Color']['menu_id'], 
							"name" => $color['Color']['name'],
							"red" => $color['Color']['red'],
							"green" => $color['Color']['green'],
							"bule" => $color['Color']['bule'],
								);
			}
			/* end */
	
			/* ヒールデータ */
			$cond = array(
				'ProductColorChip.heel <>' => 'n.d.',
				);

			$option = array(
				'fields' => 'DISTINCT ProductColorChip.heel',	
				'conditions' => $cond,
				'order' => array(
				'ProductColorChip.heel' => 'asc'
				)
			);
			$this->ProductColorChip->recursive = -1;
			$productColorChips = $this->ProductColorChip->find('all', $option);

			$heelArray = array();
			$heelCnt = 1;
			foreach($productColorChips as $productColorChip) {
				$heelArray[] = array(
							"id" => $heelCnt, 
							"menu_id" => 1, 
							"name" => $productColorChip['ProductColorChip']['heel'],
							);
				$heelCnt++;
			}
			/* end */

	
			/* プライスデータ */
			$cond = array(
				'Price.season_id' => array(1),
				'Price.delete_flg' => array(0),
				);
			$prices = $this->Price->find('all', array(
				'conditions' => $cond,
				'order' => array('Price.menu_id', 'Price.rank'),
			));
			$priceArray = array();
			foreach($prices as $price) {
				$priceArray[] = array("id" => $price['Price']['id'], 
									"menu_id" => $price['Price']['menu_id'], 
									"name" => $price['Price']['name'],
									"lowerPrice" => $price['Price']['lower_price'],
									"upperPrice" => $price['Price']['upper_price'],
									);
			}
			/* end */
		
		
			$arr = array(
				"seasonname" => $season['Season']['key'],
				"database" => $season['Season']['sqlite'],
				"content" => $contentArray,
				"menutitle" => $menuTitleArray,
				"category" => $categoryArray,
				"group" => $groupArray,
				"color" => $colorArray,
				"heel" => $heelArray,
				"price" => $priceArray,
//				),
			);
			
			$ccc[] = $arr;
		}
		
//		print_r($ccc);
		
		print json_encode($ccc);

	}



}
?>