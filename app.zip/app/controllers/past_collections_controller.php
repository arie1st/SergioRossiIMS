<?php
class PastCollectionsController extends AppController {

	var $name = 'PastCollections';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
//		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->Content->recursive = 0;
		$this->set('pastCollections', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Content', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('pastCollection', $this->PastCollection->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->PastCollection->create();
			if ($this->PastCollection->save($this->data)) {
				$this->Session->setFlash(__('The PastCollection has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The PastCollection could not be saved. Please, try again.', true));
			}
		}
//		$seasons = $this->Content->Season->find('list');
//		$this->set(compact('seasons'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid PastCollection', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->PastCollection->save($this->data)) {
				$this->Session->setFlash(__('The PastCollection has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The PastCollection could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->PastCollection->read(null, $id);
		}
//		$seasons = $this->Content->Season->find('list');
//		$this->set(compact('seasons'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Content', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Content->del($id)) {
			$this->Session->setFlash(__('Content deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Content could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>