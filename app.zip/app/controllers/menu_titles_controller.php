<?php
class MenuTitlesController extends AppController {

	var $name = 'MenuTitles';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
//		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->MenuTitle->recursive = 0;
		$this->set('menuTitles', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid MenuTitle', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('menuTitle', $this->MenuTitle->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->MenuTitle->create();
			if ($this->MenuTitle->save($this->data)) {
				$this->Session->setFlash(__('The MenuTitle has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The MenuTitle could not be saved. Please, try again.', true));
			}
		}
		$seasons = $this->MenuTitle->Season->find('list');
		$this->set(compact('seasons'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid MenuTitle', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->MenuTitle->save($this->data)) {
				$this->Session->setFlash(__('The MenuTitle has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The MenuTitle could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->MenuTitle->read(null, $id);
		}
		$seasons = $this->MenuTitle->Season->find('list');
		$this->set(compact('seasons'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for MenuTitle', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->MenuTitle->del($id)) {
			$this->Session->setFlash(__('MenuTitle deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The MenuTitle could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>