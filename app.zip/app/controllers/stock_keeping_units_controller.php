<?php
class StockKeepingUnitsController extends AppController {

	var $name = 'StockKeepingUnits';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());

//		$cond = array(
//			'Shop.id' => array($this->Auth->user('shop_id')),
//			);
//		$userShop = $this->Staff->Shop->find('first', array(
//			'conditions' => $cond,
//			'fields' => array('Shop.name'),
//		));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->StockKeepingUnit->recursive = 0;
		$this->set('stockKeepingUnits', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid StockKeepingUnit', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('stockKeepingUnit', $this->StockKeepingUnit->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->StockKeepingUnit->create();
			if ($this->StockKeepingUnit->save($this->data)) {
				$this->Session->setFlash(__('The StockKeepingUnit has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The StockKeepingUnit could not be saved. Please, try again.', true));
			}
		}
		$products = $this->StockKeepingUnit->Product->find('list');
		$this->set(compact('products'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid StockKeepingUnit', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->StockKeepingUnit->save($this->data)) {
				$this->Session->setFlash(__('The StockKeepingUnit has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The StockKeepingUnit could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->StockKeepingUnit->read(null, $id);
		}
//		$products = $this->StockKeepingUnit->Product->find('list');
		$this->set(compact('products'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for StockKeepingUnit', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->StockKeepingUnit->del($id)) {
			$this->Session->setFlash(__('StockKeepingUnit deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The StockKeepingUnit could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>