<?php
class ProductColorChipsController extends AppController {

	var $name = 'ProductColorChips';
	var $uses = array('ProductColorChip', 'Material', 'ColorChip');
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
//		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->ProductColorChip->recursive = 0;
		$this->set('productColorChips', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid ProductColorChip', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('productColorChip', $this->ProductColorChip->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->ProductColorChip->create();
			if ($this->ProductColorChip->save($this->data)) {
				$this->Session->setFlash(__('The ProductColorChip has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The ProductColorChip could not be saved. Please, try again.', true));
			}
		}
		$products = $this->ProductColorChip->Product->find('list');
		$materials = $this->ProductColorChip->Material->find('list');
		$colorChips = $this->ProductColorChip->ColorChip->find('list');
		$this->set(compact('products','materials','colorChips'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid ProductColorChip', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->ProductColorChip->save($this->data)) {
				$this->Session->setFlash(__('The ProductColorChip has been saved', true));
				$this->redirect(array('action' => 'view', $id));
			} else {
				$this->Session->setFlash(__('The ProductColorChip could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->ProductColorChip->read(null, $id);
		}
		$products = $this->ProductColorChip->Product->find('list');
		$materials = $this->ProductColorChip->Material->find('list');
		$colorChips = $this->ProductColorChip->ColorChip->find('list');
		$this->set(compact('products','materials','colorChips'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for ProductColorChip', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->ProductColorChip->del($id)) {
			$this->Session->setFlash(__('ProductColorChip deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The ProductColorChip could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>