<?php
class MessagesController extends AppController {

	var $name = 'Messages';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Message->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$option = array(
				'conditions' => array(
				'Message.to_shop_id' => HEAD_SHOP,
				),
				'limit' => 20,
				'order' => array(
				'Message.created' => 'desc'
				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('messages', $data);
			$viewTemplate = "index_main";			
		} else if ( $userLevel == STAFF_USER ) {
		
			$option = array(
				'conditions' => array(
				'Message.from_shop_id <>' => SYSTEM_SHOP,
				'Message.to_shop_id' => array(ALL_SHOP, $userShopId),
				),
				'limit' => 20,
				'order' => array(
				'Message.created' => 'desc'
				)
			);
		
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('messages', $data);
			$viewTemplate = "index_staff";			
		} else if ( $userLevel == SYSTEM_USER ) {
			$this->Message->recursive = 0;
			$this->set('messages', $this->paginate());
			$viewTemplate = "index_admin";			
		}
		$this->render($viewTemplate);
	}

	function registerList() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "register_list_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "register_list_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "register_list_admin";			
		}

		$option = array(
			'conditions' => array(
			'Message.from_shop_id' => $userShopId,
			),
			'limit' => 20,
			'order' => array(
			'Message.created' => 'desc'
			)
		);

		if ( $userLevel == HEAD_USER ) {
			$this->Message->recursive = 0;
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('messages', $data);
		} else if ( $userLevel == STAFF_USER ) {
			$this->Message->recursive = 0;
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('messages', $data);
		} else if ( $userLevel == SYSTEM_USER ) {
			$this->Message->recursive = 0;
			$this->set('messages', $this->paginate());
		}
		$this->render( $viewTemplate );			
	}

	function view($id = null) {
		$userLevel = $this->Auth->user('level');
		if (!$id) {
			$this->Session->setFlash(__('Invalid Message', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('message', $this->Message->read(null, $id));
		if ( $userLevel == 1 ) {
			$this->render("view_main");
		} else if ( $userLevel == 2 ) {
			$this->render("view_staff");
		} else if ( $userLevel == 9 ) {
			$this->render("view_admin");			
		}

	}

	function add() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');
		if (!empty($this->data)) {
			if ( $this->data['Message']['mode'] == 'confirm') {
				$this->Message->set($this->data);
				if( !$this->Message->validates($this->Message) ) {
					$this->validateErrors($this->Message);
					
					$staffs = $this->Message->Staff->find('list');
					$this->set(compact('staffs'));
			
					$cond = array('ShopTo.delete_flg' => '0');
					$shops = $this->Message->ShopTo->find('list', array(
						'conditions' => $cond,
					));
					$this->set(compact('shops'));
			
					if ( $userLevel == 1 ) {
						$this->render("add_main");
					} else if ( $userLevel == 2 ) {
						$this->render("add_staff");
					} else if ( $userLevel == 9 ) {
						$this->render("add_admin");			
					}
				} else {
					$this->set('data', $this->data);
					if ( $userLevel == 1 ) {
						$this->render("add_main_confirm");
					} else if ( $userLevel == 2 ) {
						$this->render("add_staff_confirm");
					} else if ( $userLevel == 9 ) {
						$this->render("add_admin_confirm");			
					}
				}
			} else if ( $this->data['Message']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				$shop_id = $this->Auth->user('shop_id');
				
				if ( $userLevel == 1 ) {
					$from_shop_id = $shop_id;
					$tempctp = 'add_main_register';
				} else if ( $userLevel == 2 ) {
					$from_shop_id = $shop_id;
					$tempctp = 'add_staff_register';
				} else if ( $userLevel == 9 ) {
					$from_shop_id = $shop_id;
					$tempctp = 'add_admin_register';
				}
				
				$data = array (
					'Message' => array (
						'staff_id' => $this->data['Message']['staff_id'],
						'from_shop_id' => $from_shop_id,
						'to_shop_id' => $this->data['Message']['to_shop_id'],
						'staff_name' => $this->data['Message']['staff_name'],
						'subject' => $this->data['Message']['subject'],
						'body' => $this->data['Message']['body'],
						'approve_flg' => 1,
						'delete_flg' => 0,
						'creator_id' => $staff_id,
						'updater_id' => $staff_id,
					)
				);
				$this->Message->create();
				if ($this->Message->save($data)) {
					$this->render($tempctp);
				}
			}
		} else {
			$staffs = $this->Message->Staff->find('list');
			$this->set(compact('staffs'));
			
			$cond = array(
				'ShopTo.kind_id' => array('1', '0'),
				'ShopTo.id <>' => $userShopId,
				'ShopTo.delete_flg' => '0',
				);
			$shops = $this->Message->ShopTo->find('list', array(
				'conditions' => $cond,
			));
			$this->set(compact('shops'));
			
			if ( $userLevel == 1 ) {
				$this->render("add_main");
			} else if ( $userLevel == 2 ) {
				$this->render("add_staff");
			} else if ( $userLevel == 9 ) {
				$this->render("add_admin");			
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Message', true));
			$this->redirect(array('action' => 'index'));
		}
		
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');
		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = 'edit_main';
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = 'edit_staff';
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = 'edit_admin';
		}

		if (!empty($this->data)) {
			if ( $this->data['Message']['mode'] == 'confirm') {
				$this->Message->set($this->data);
				if( !$this->Message->validates($this->Message) ) {
					$this->validateErrors($this->Message);
				} else {
					$this->set('data', $this->data);
					if ( $userLevel == 1 ) {
						$viewTemplate = 'edit_main_confirm';
					} else if ( $userLevel == 2 ) {
						$viewTemplate = 'edit_staff_confirm';
					} else if ( $userLevel == 9 ) {
						$viewTemplate = 'edit_admin_confirm';
					}
				}
			} else if ( $this->data['Message']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				if ( $userLevel == 1 ) {
					$viewTemplate = 'edit_main_register';
				} else if ( $userLevel == 2 ) {
					$viewTemplate = 'edit_staff_register';
				} else if ( $userLevel == 9 ) {
					$viewTemplate = 'edit_admin_register';
				}

				$data = array (
					'Message' => array (
						'id' => $id,
//						'staff_id' => $this->data['Message']['staff_id'],
//						'from_shop_id' => $this->data['Message']['from_shop_id'],
						'to_shop_id' => $this->data['Message']['to_shop_id'],
//						'staff_name' => $this->data['Message']['staff_name'],
						'subject' => $this->data['Message']['subject'],
						'body' => $this->data['Message']['body'],
//						'approve_flg' => 1,
//						'delete_flg' => 0,
//						'creator_id' => $staff_id,
						'updater_id' => $staff_id,
					)
				);
				if ($this->Message->save($data)) {
//					$this->render( $viewTemplate );
				}
			}
		} else {
			if (empty($this->data)) {
				$this->data = $this->Message->read(null, $id);
			}
			if ( $userLevel == HEAD_USER ) {
				$viewTemplate = 'edit_main';
			} else if ( $userLevel == STAFF_USER ) {
				$viewTemplate = 'edit_staff';
			} else if ( $userLevel == SYSTEM_USER ) {
				$viewTemplate = 'edit_admin';
			}
			
			$staffs = $this->Message->Staff->find('list');
			$this->set(compact('staffs'));
			
			$cond = array(
				'ShopTo.kind_id' => array('1', '0'),
				'ShopTo.id <>' => $userShopId,
				'ShopTo.delete_flg' => '0',
				);
			$shops = $this->Message->ShopTo->find('list', array(
				'conditions' => $cond,
			));
			$this->set(compact('shops'));

		}		
		$this->render( $viewTemplate );
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Message', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Message->del($id)) {
			$this->Session->setFlash(__('Message deleted', true));
			$this->redirect(array('action' => 'from'));
		}
		$this->Session->setFlash(__('The Message could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>