<?php
class ImageProductsController extends AppController {

	var $name = 'ImageProducts';
	var $uses = array();
	var $helpers = array('Html', 'Form');

	public $autoLayout = false;

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
	}

	function upload() {
//		$this->StockKeepingUnit->recursive = 0;
//		$this->set('stockKeepingUnits', $this->paginate());
	}



}
?>