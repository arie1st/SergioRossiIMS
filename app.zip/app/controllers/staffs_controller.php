<?php
class StaffsController extends AppController {

	var $name = 'Staffs';
	var $uses = array('Staff', 'Accesslog');
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth', 'RequestHandler');

	function beforeFilter() {

		$this->Auth->userModel = 'Staff';
		$this->Auth->allow('webLogin');
		$this->Auth->autoRedirect = false; 
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());

		$cond = array(
			'Shop.id' => array($this->Auth->user('shop_id')),
			);
		$userShop = $this->Staff->Shop->find('first', array(
			'conditions' => $cond,
			'fields' => array('Shop.name'),
		));
		$this->set(compact('userShop'));	
	}

	function login() {

		if ($this->Auth->user()) {
        	if (!empty($this->data)) {
        
				$cond = array(
					'Staff.staff_number' => array( $this->data['Staff']['staff_number'] ),
					'Staff.password' => array( $this->data['Staff']['password'] ),
				);
				$staff = $this->Staff->find('all', array(
					'conditions' => $cond
				));
				$staffId = $staff[0]['Staff']['id'];
				$staffNumber = $staff[0]['Staff']['staff_number'];
				$staffName = $staff[0]['Staff']['name'];
				$staffPassword = $staff[0]['Staff']['password'];
				$shopId = $staff[0]['Staff']['shop_id'];

				$staffShop = $this->Staff->getStaffShop($shopId);

				$accesslog = array(
					"shop_id" => $shopId,
					'staff_id' => $staffId,
					"shop_name" => $staffShop['Shop']['name'],
					"staff_number" => $staffNumber,
					"staff_name" => $staffName,
					"ipaddress" => $this->RequestHandler->getClientIP(),
				);
				$this->Accesslog->create();
				$this->Accesslog->save($accesslog);
				
				$url = $this->Auth->redirect();

	            if($url == DS) {
	                $this->redirect('/admin');
	            } else {
	                $this->redirect($url);
	            }
				
//				$this->redirect($this->Auth->redirect());
			}
        }
	}
	
	function webLogin() {
		$this->autoRender = false;
		Configure::write('debug', 0);
		if (!empty($this->data)) {
			
			$cond = array(
				'Staff.staff_number' => array( $this->data['Staff']['staff_number'] ),
				'Staff.password' => array( $this->data['Staff']['password'] ),
				);
			$staff = $this->Staff->find('all', array(
				'conditions' => $cond
			));
			
			if ( count($staff) != 0 ) {
				$staffId = $staff[0]['Staff']['id'];
				$staffNumber = $staff[0]['Staff']['staff_number'];
				$staffName = $staff[0]['Staff']['name'];
				$staffPassword = $staff[0]['Staff']['password'];
				$shopId = $staff[0]['Staff']['shop_id'];
				$staffShop = $this->Staff->getStaffShop($shopId);
			
				print '<?xml version="1.0" encoding="UTF-8"?>'."\n";
				print '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'."\n";
				print '<plist version="1.0">'."\n";
				print '<dict>'."\n";
				print '<key>login</key>'."\n";
				print '<true/>'."\n";
				print '<key>staff_id</key>'."\n";
				printf( "<string>%s</string>\n",  $staffId );
				print '<key>staff_number</key>'."\n";
				printf( "<string>%s</string>\n",  $staffNumber );
				print '<key>staff_name</key>'."\n";
				printf( "<string>%s</string>\n",  $staffName );
				print '<key>staff_password</key>'."\n";
				printf( "<string>%s</string>\n",  $staffPassword );
				print '<key>shop_id</key>'."\n";
				printf( "<string>%s</string>\n",  $shopId );
				print '<key>shop_name</key>'."\n";
				printf( "<string>%s</string>\n",  $staffShop['Shop']['name'] );
				print '</dict>'."\n";
				print '</plist>'."\n";
				
				$accesslog = array(
					"shop_id" => $shopId,
					'staff_id' => $staffId,
					"shop_name" => $staffShop['Shop']['name'],
					"staff_number" => $staffNumber,
					"staff_name" => $staffName,
					"ipaddress" => $this->RequestHandler->getClientIP(),
				);
				$this->Accesslog->create();
				$this->Accesslog->save($accesslog);
				
			} else {
				print '<?xml version="1.0" encoding="UTF-8"?>'."\n";
				print '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'."\n";
				print '<plist version="1.0">'."\n";
				print '<dict>'."\n";
				print '<key>login</key>'."\n";
				print '<false/>'."\n";
				print '<key>staff_id</key>'."\n";
				print '<string></string>'."\n";
				print '<key>staff_number</key>'."\n";
				print '<string></string>'."\n";
				print '<key>staff_name</key>'."\n";
				print '<string></string>'."\n";
				print '<key>staff_password</key>'."\n";
				print '<string></string>'."\n";
				print '<key>shop_id</key>'."\n";
				print '<string></string>'."\n";
				print '<key>shop_name</key>'."\n";
				print '<string></string>'."\n";
				print '</dict>'."\n";
				print '</plist>'."\n";
			}
		} else {
				print '<?xml version="1.0" encoding="UTF-8"?>'."\n";
				print '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'."\n";
				print '<plist version="1.0">'."\n";
				print '<dict>'."\n";
				print '<key>login</key>'."\n";
				print '<false/>'."\n";
				print '<key>staff_id</key>'."\n";
				print '<string></string>'."\n";
				print '<key>staff_number</key>'."\n";
				print '<string></string>'."\n";
				print '<key>staff_name</key>'."\n";
				print '<string></string>'."\n";
				print '<key>staff_password</key>'."\n";
				print '<string></string>'."\n";
				print '<key>shop_id</key>'."\n";
				print '<string></string>'."\n";
				print '<key>shop_name</key>'."\n";
				print '<string></string>'."\n";
				print '</dict>'."\n";
				print '</plist>'."\n";
		}
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('action' => 'index'));
	}

	function index() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$option = array(
				'conditions' => array(
				'Staff.level' => array('1', '2'),
				'Staff.delete_flg' => 0,
				),
				'limit' => 20,
//				'order' => array(
//				'Message.created' => 'desc'
//				)
			);
			$this->paginate = $option;
			$data = $this->paginate();
			$this->set('staffs', $data);
			$viewTemplate = 'index_main';
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = 'index_staff';

			//-- 本部からのメッセージを取得
			$cond = array(
				'Knowhow.send_shop_id' => array('1', '2'),
				'Knowhow.shop_id' => array('0', $userShopId),
				'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
				);
			$knowhows = $this->Staff->Knowhow->find('all', array(
				'conditions' => $cond,
				'limit' => 5,
				'order' => array(
				'Knowhow.created' => 'desc'
				)
			));
			$this->set(compact('knowhows'));
			

		$searchDay = date("Y-m-d", strtotime("-1 day"));

		//-- 
		$shopResults = $this->Staff->Knowhow->query("SELECT 
			`Knowhow`.`shop_id`, `Knowhow`.`shop_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay'
			GROUP BY `Knowhow`.`shop_id`, `Knowhow`.`shop_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($shopResults as $key => $row) {
			if (!empty($row[0]['created'])) {
				$shopResults[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($shopResults[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$shopResults[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($shopResults[$key][0]['count']);
			}
		}
		$this->set('shopRanking', $shopResults);
		
		//--
		$staffResults = $this->Staff->Knowhow->query("SELECT 
			`Knowhow`.`shop_id`, `Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay'
			GROUP BY `Knowhow`.`shop_id`, `Knowhow`.`staff_id`, `Knowhow`.`shop_name`, `Knowhow`.`staff_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($staffResults as $key => $row) {
			if (!empty($row[0]['created'])) {
				$staffResults[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($staffResults[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$staffResults[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($staffResults[$key][0]['count']);
			}
		}
		$this->set('staffRanking', $staffResults);

		//--
		$productResults = $this->Staff->Knowhow->query("SELECT 
			`Knowhow`.`product_id`, `Knowhow`.`product_name`, date(`Knowhow`.`created`) AS created, COUNT(`Knowhow`.`id`) AS count
			FROM `knowhows` AS `Knowhow` 
			WHERE date(`Knowhow`.`created`) = '$searchDay' AND `Knowhow`.`product_id`<>0
			GROUP BY `Knowhow`.`product_id`, `Knowhow`.`product_name`
			ORDER BY count(`Knowhow`.`id`) DESC LIMIT 0, 10;");
			
		foreach ($productResults as $key => $row) {
			if (!empty($row[0]['created'])) {
				$productResults[$key]['Knowhow']['created'] = $row[0]['created'];
				unset($productResults[$key][0]['created']);
			}
			if (!empty($row[0]['count'])) {
				$productResults[$key]['Knowhow']['count'] = $row[0]['count'];
				unset($productResults[$key][0]['count']);
			}
		}
		$this->set('productRanking', $productResults);

		
					
		} else if ( $userLevel == SYSTEM_USER ) {
			$this->Staff->recursive = 0;
			$this->set('staffs', $this->paginate());
			$viewTemplate = 'index_admin';
			
		}
		$this->render($viewTemplate);
	}

	function view($id = null) {
		$userLevel = $this->Auth->user('level');

		if (!$id) {
			$this->Session->setFlash(__('Invalid Staff', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('staff', $this->Staff->read(null, $id));
		
		if ( $userLevel == 1 ) {
			$this->render("view_main");
		} else if ( $userLevel == 2 ) {
//			$this->render("index_staff");
		} else if ( $userLevel == 9 ) {
			$this->render("view_admin");			
		}
	}

	function add() {
		$userLevel = $this->Auth->user('level');
		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = 'add_main';
		} else if ( $userLevel == STAFF_USER ) {
//			$viewTemplate = 'add_staff_confirm';
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = 'add_admin';
		}

		if (!empty($this->data)) {
			if ( $this->data['Staff']['mode'] == 'confirm') {
				$this->Staff->set($this->data);
				if( !$this->Staff->validates($this->Staff) ) {
					$this->validateErrors($this->Staff);
				} else {
					$this->set('data', $this->data);
//					$this->render("add_confirm");
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = 'add_main_confirm';
					} else if ( $userLevel == STAFF_USER ) {
//						$viewTemplate = 'add_staff_confirm';
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = 'add_admin_confirm';
					}
				}
			} else if ( $this->data['Staff']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				$data = array (
					'Staff' => array (
						'shop_id' => $this->data['Staff']['shop_id'],
						'staff_number' => $this->data['Staff']['staff_number'],
						'password' => $this->Auth->password($this->data['Staff']['password1']),
						'name' => $this->data['Staff']['name'],
						'furigana' => $this->data['Staff']['furigana'],
						'email' => $this->data['Staff']['email'],
						'level' => $this->data['Staff']['level'],
						'delete_flg' => 0,
						'creator_id' => $staff_id,
						'updater_id' => $staff_id,
					)
				);
				$this->Staff->create();
				if ($this->Staff->save($data)) {
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = 'add_main_register';
					} else if ( $userLevel == STAFF_USER ) {
//						$viewTemplate = 'add_staff_register';
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = 'add_admin_register';
					}
//					$this->render("add_register");
				}
			}
		}
		$cond = array('Shop.kind_id' => '0', 'Shop.delete_flg' => '0');
		$shops = $this->Staff->Shop->find('list', array(
			'conditions' => $cond,
			));
		$this->set(compact('shops'));
		$this->render( $viewTemplate );
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Staff', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
		
			if ( $this->data['Staff']['mode'] == 'confirm' ) {
				$data = array (
					'Staff' => array (
						'id' => $this->data['Staff']['id'],
						'shop_id' => $this->data['Staff']['shop_id'],
						'password1' => $this->data['Staff']['password1'],
						'password2' => $this->data['Staff']['password2'],
						'name' => $this->data['Staff']['name'],
						'furigana' => $this->data['Staff']['furigana'],
						'level' => $this->data['Staff']['level'],
					)
				);
				
				if ( $this->data['Staff']['staff_number'] != $this->data['Staff']['staff_number_old'] ) {
					$data['Staff']['staff_number'] =  $this->data['Staff']['staff_number'];
				}
				if ( $this->data['Staff']['email'] != $this->data['Staff']['email_old'] ) {
					$data['Staff']['email'] =  $this->data['Staff']['email_old'];
				}

				$this->Staff->set($data);
				if( !$this->Staff->validates($this->Staff) ) {
					$this->validateErrors($this->Staff);
				} else {
					$this->set('data', $this->data);
					$this->render("edit_confirm");
				}
			} else if ( $this->data['Staff']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				
				$data = array (
					'Staff' => array (
						'id' => $this->data['Staff']['id'],
						'shop_id' => $this->data['Staff']['shop_id'],
						'password' => $this->Auth->password($this->data['Staff']['password1']),
						'name' => $this->data['Staff']['name'],
						'furigana' => $this->data['Staff']['furigana'],
						'level' => $this->data['Staff']['level'],
						'delete_flg' => 0,
						'updater_id' => $staff_id,
					)
				);
				
				if ( $this->data['Staff']['staff_number'] != $this->data['Staff']['staff_number_old'] ) {
					$data['Staff']['staff_number'] =  $this->data['Staff']['staff_number'];
				}
				
				if ( $this->data['Staff']['email'] != $this->data['Staff']['email_old'] ) {
					$data['Staff']['email'] =  $this->data['Staff']['email_old'];
				}
				
				if ($this->Staff->save($data)) {
					$this->render("edit_register");
				}
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Staff->read(null, $id);
		}
		$cond = array('Shop.kind_id' => '0', 'Shop.delete_flg' => '0');
		$shops = $this->Staff->Shop->find('list', array(
			'conditions' => $cond,
			));
		$this->set(compact('shops'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Staff', true));
			$this->redirect(array('action' => 'index'));
		}
		$staff_id = $this->Auth->user('id');
		$data = array (
			'Staff' => array (
				'id' => $id,
				'password' => '',
				'delete_flg' => 1,
				'updater_id' => $staff_id,
			)
		);
		if ($this->Staff->save($data)) {
//			$this->Session->setFlash(__('Staff deleted', true));
			$this->redirect(array('action' => 'index'));
		}
//		if ($this->Staff->del($id)) {
//			$this->Session->setFlash(__('Staff deleted', true));
//			$this->redirect(array('action' => 'index'));
//		}
		$this->Session->setFlash(__('スタッフ情報を削除します。よろしいですか？', true));
		$this->redirect(array('action' => 'index'));
	}

	function csv() {
		$userLevel = $this->Auth->user('level');
		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "csv_main";
		} else if ( $userLevel == STAFF_USER ) {
//			$viewTemplate = "csv_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "csv_admin";
		}

		if (!empty($this->data)) {

			$fileName = "/tmp/result.csv";

			if ( $this->data['Staff']['mode'] == 'confirm' ) {
				$tmp_file = $this->data['Staff']['csvfile']['tmp_name'];
				if( is_uploaded_file($tmp_file) === true ) {
					copy($tmp_file, $fileName);
		            $csvData = file($fileName, FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);
		            
		            $this->Staff->validate = $this->Staff->validateCsv;

					$i = 0;
					foreach($csvData as $line){
						if ($i != 0) {
						$record = split(",", $line);
						$shopData = $this->Staff->SearchShop($record[0]);
						$data = array(
							"shop_id" => $shopData['Shop']['id'],
							"shop_name" => $shopData['Shop']['name'],
							"staff_number" => $record[1],
							"password" => $record[2],
							"name" => $record[3],
							"furigana" => $record[4],
							"email" => $record[5],
						);
						$this->Staff->set($data);
						if( !$this->Staff->validates($this->Staff) ) {
							$error[] = $this->validateErrors($this->Staff);
						} else {
							$error[] = array();
						}
						$staffData[] = $data;
						}
						$i++;
					}

					$this->set('data', $staffData);
					$this->set('error', $error);
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = "csv_main_confirm";
					} else if ( $userLevel == STAFF_USER ) {
//						$viewTemplate = "csv_staff_register";
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = "csv_admin_confirm";
					}
				}
			} else if ( $this->data['Staff']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				if ( $userLevel == HEAD_USER ) {
				
		            $csvData = file($fileName, FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);

					foreach($csvData as $line){
						$record = split(",", $line);
			
						$shopData = $this->Staff->SearchShop($record[0]);
						$data = array(
							"shop_id" => $shopData['Shop']['id'],
							"staff_number" => $record[1],
							"password" => $this->Auth->password($record[2]),
							"name" => $record[3],
							"furigana" => $record[4],
							"email" => $record[5],
							"level" => 2,
							'delete_flg' => 0,
							'creator_id' => $staff_id,
							'updater_id' => $staff_id,
						);
						$this->Staff->create();
						$this->Staff->save($data);
					}
					$viewTemplate = "csv_main_register";
				} else if ( $userLevel == STAFF_USER ) {
//					$viewTemplate = "csv_staff_register";
				} else if ( $userLevel == SYSTEM_USER ) {
					$viewTemplate = "csv_admin_register";
				}
			}
		}
		$this->render($viewTemplate);
	}

}
?>