<?php
class ColorsController extends AppController {

	var $name = 'Colors';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
//		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->Color->recursive = 0;
		$this->set('colors', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Color', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('color', $this->Color->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Color->create();
			if ($this->Color->save($this->data)) {
				$this->Session->setFlash(__('The Color has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Color could not be saved. Please, try again.', true));
			}
		}
		$seasons = $this->Color->Season->find('list');
		$this->set(compact('seasons'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Color', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Color->save($this->data)) {
				$this->Session->setFlash(__('The Color has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Color could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Color->read(null, $id);
		}
		$seasons = $this->Color->Season->find('list');
		$this->set(compact('seasons'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Color', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Color->del($id)) {
			$this->Session->setFlash(__('Color deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Color could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>