<?php
class ClippingsController extends AppController {
 	var $components = array('Auth', 'FileUpload');
	var $name = 'Clippings';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	
	function beforeFilter() {
		$this->FileUpload->fileModel = null; 
		$this->FileUpload->fileVar = 'file';
		$this->FileUpload->uploadDir = 'data/csv/';
		$this->FileUpload->allowedTypes = array('text/csv csv', 'text/comma-separated-values csv', '-application/octet-stream', '-text/comma','application/vnd.ms-excel',);
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
//		$userShop = $this->Knowhow->getStaffShop($this->Auth->user('shop_id'));
//		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$delfile = new File('data/csv/clipping.csv');
		$delfile->delete();
		
		$sql= "delete from clippings where rank='0' ";
		$this->Clipping->query($sql);
		
		
		
		$this->Clipping->recursive = 0;
		
		
		$option = array(
			'conditions' => array( 
//			'Knowhow.send_shop_id' => array('2', '3'),
//			'Knowhow.product_id' => array('0'),
//			'Knowhow.approval_flg' => APPROVAL_KNOWHOW,
			'Clipping.delete_flg' => array('0'),
			),
			'limit' => 50,
			'order' => array(
			'Clipping.id' => 'desc'
			)
		);
		$this->paginate = $option;
		$data = $this->paginate();

		$this->set('clippings', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Content', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('clipping', $this->Clipping->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Clipping->create();
			if ($this->Clipping->save($this->data)) {
				$this->Session->setFlash(__('The Clipping has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Clipping could not be saved. Please, try again.', true));
			}
		}
//		$seasons = $this->Content->Season->find('list');
//		$this->set(compact('seasons'));
	}
	
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Clipping', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Clipping->save($this->data)) {
				$this->Session->setFlash(__('The Clipping has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Clipping could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Clipping->read(null, $id);
		}
//		$seasons = $this->Content->Season->find('list');
//		$this->set(compact('seasons'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Content', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Clipping->del($id)) {
			$this->Session->setFlash(__('Clipping deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Content could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

	function csv() {
	
		set_time_limit(7200);
		
		$viewTemplate = 'csv';
		
		if (!empty($this->data)) {

			$fileName = "/tmp/clipings.csv";

			if ( $this->data['Clipping']['mode'] == 'regsister' ) {
				$tmp_file = $this->data['Clipping']['csvfile']['tmp_name'];
				if( is_uploaded_file($tmp_file) === true ) {
					copy($tmp_file, $fileName);
		            $csvData = file($fileName, FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);
		            
		            $cnt = 0;
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue;
						}
						$record = split(",", $line);

						$data['Clipping'] = array(
							"thumbnail" => $seasonId.'_'.$record[1],
							"filename" => $seasonId.'_'.$record[1],
							"name" => $seasonId.'_'.$record[1],
							"text" => $seasonId.'_'.$record[1],
							"rank" => $seasonId.'_'.$record[1],
						);
						$this->Clipping->save($data);
					}
					$viewTemplate = 'csv_register';
				}
			}/* else if ( $this->data['Product']['mode'] == 'regsister' ) {
			}
*/
		}
		$this->render($viewTemplate);
	}
	
	function download(){
	
		ini_set('max_execution_time', 600); //increase max_execution_time to 10 min if data set is very large
	 
		//create a file
		$filename = "clippings_".date("Y.m.d").".csv";
		$csv_file = fopen('php://output', 'w');
		 
		header('Content-type: text/csv; charset= UTF-8 ');
		header('Content-Disposition: attachment; filename="'.$filename.'"');
		 
		//$sql="select * from clippings where delete_flg=0;";
		//$results = $this->Clipping->query("SELECT * FROM clippings WHERE delete_flg = 0;"); // This is your sql query to pull that data you need exported
		//or
		$conditions = array("delete_flg" => "0");
		$results = $this->Clipping->find('all', array('conditions' => $conditions));
		 
		// The column headings of your .csv file
		$header_row = array(mb_convert_encoding('拡大画像','Shift_JIS','UTF-8'), mb_convert_encoding('サムネイル画像','Shift_JIS','UTF-8'), mb_convert_encoding('キャプション','Shift_JIS','UTF-8'),  mb_convert_encoding('順番','Shift_JIS','UTF-8'));
		//$header_row = array('拡大画像','サムネイル画像','キャプション','順番');
		fputcsv($csv_file,$header_row,',','"');
		 
		// Each iteration of this while loop will be a row in your .csv file where each field corresponds to the heading of the column
		foreach($results as $result)
		{
		// Array indexes correspond to the field names in your db table(s)
		$row = array(
		$result['Clipping']['filename'],
		$result['Clipping']['thumbnail'],
		mb_convert_encoding($result['Clipping']['text'],'Shift_JIS','UTF-8'),
		$result['Clipping']['rank'],
		);
		 
		fputcsv($csv_file,$row,',','"');
		}
		 
		fclose($csv_file);
		exit;
	}
	
		//arie 28082012
	function add_bulk(){
	    $today = date("Y-m-d 00:00:00");
		//upload csv file 
		$file = new File('data/csv/clipping.csv');
		
		//$getfilename= basename($this->request->data['file']);
		//print_r($getfilename);
		/*if($file->exists()){
		$file->delete();
		}*/
		
		//else{
		parent::beforeFilter();
		$this->FileUpload->fields = array('name'=> 'file_name', 'type' => 'file_type', 'size' => 'file_size');
		
		if($this->FileUpload->success){
			//UPDATE clipping set delete_flg = 1, modified = now WHERE delete_flg = 0;
			  $this->Clipping->updateAll(array('delete_flg'=>"1",'modified'=>"'=now()'"),array('delete_flg'=>"0"));
			  $this->Clipping->save();
		
		
			//delete existing data logically(set 1 to delete_flg)
			//UPDATE clipping set delete_flg = 1, modified = now WHERE delete_flg = 0;
			
			//$this->Clipping->updateAll(array('delete_flg'=>"'1'",'modified'=>"'=now()'"),array('delete_flg'=>"'0'"));
			//$this->Clipping->save();
		
			//reading uploaded csv
			if($file->exists()){
				$handle = fopen('data/csv/clipping.csv', "r"); 
	
		
				//insert data to database
/*
				$sql = "LOAD DATA LOCAL INFILE '".$file2."' INTO TABLE clippings 
				FIELDS
					TERMINATED BY ','
					ENCLOSED BY '\"'
		    	LINES
					TERMINATED BY '\\r\\n' 
					IGNORE 1 LINES
				(filename, thumbnail, text, rank)
				";
				
				$this->Clipping->query($sql);
				$this->Clipping->save();
*/

				while (($data = fgetcsv($handle,1000, ",")) !== FALSE) {
					$this->Clipping->create();
					$this->Clipping->save(array('text'=>$data[2],'thumbnail'=>$data[1],'filename'=>$data[0],'rank'=>$data[3],'creator_id'=>'0', 'updater_id'=>'0', 'created'=>'$today',  'modified'=>'','delete_flg'=>'0',));
				}
		
		
		 		// close the file
		 		fclose($handle);

			}
		
			//$sql= "delete from clippings where rank='0' ";
			//$this->Clipping->query($sql);
		
			$this->Session->setFlash(__('登録が完了しました。', true));		//csv succesfully uploaded and inserted to database
		}
		else{
			$this->Session->setFlash($this->FileUpload->showErrors()); 
		}
		//}
	}

	//end arie 28082012
	function image_upload(){
		$this->layout="noHeader";
	}
}
?>