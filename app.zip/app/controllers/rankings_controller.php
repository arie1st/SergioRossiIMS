<?php
class RankingsController extends AppController {

	var $name = 'Rankings';
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Ranking->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "index_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "index_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "index_admin";			
		}

//		$this->Ranking->recursive = 0;
//		$this->set('rankings', $this->paginate());
		
		$this->render( $viewTemplate );			
	}

	function shopMonth() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "shop_month_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "shop_month_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "shop_month_admin";			
		}
		
		$this->render( $viewTemplate );			
	}

	function shopDay() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "shop_day_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "shop_day_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "shop_day_admin";			
		}
		
		$this->render( $viewTemplate );			
	}

	function staffMonth() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "staff_month_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "staff_month_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "staff_month_admin";			
		}
		
		$this->render( $viewTemplate );			
	}

	function staffDay() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "staff_day_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "staff_day_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "staff_day_admin";			
		}
		
		$this->render( $viewTemplate );			
	}

	function productMonth() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "product_month_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "product_month_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "product_month_admin";			
		}
		
		$this->render( $viewTemplate );			
	}

	function productDay() {
		$userLevel = $this->Auth->user('level');
		$userShopId = $this->Auth->user('shop_id');

		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "product_day_main";
		} else if ( $userLevel == STAFF_USER ) {
			$viewTemplate = "product_day_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "product_day_admin";			
		}
		
		$this->render( $viewTemplate );			
	}




	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Ranking', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('ranking', $this->Ranking->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Ranking->create();
			if ($this->Ranking->save($this->data)) {
				$this->Session->setFlash(__('The Ranking has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Ranking could not be saved. Please, try again.', true));
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Ranking', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Ranking->save($this->data)) {
				$this->Session->setFlash(__('The Ranking has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Ranking could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Ranking->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Ranking', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Ranking->del($id)) {
			$this->Session->setFlash(__('Ranking deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Ranking could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

}
?>