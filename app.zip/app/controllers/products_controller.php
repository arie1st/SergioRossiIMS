<?php
class ProductsController extends AppController {

	var $name = 'Products';
	var $uses = array('Product', 'Season', 'Group', 'Category', 'Material', 'Color', 'ColorChip', 'ProductColorChip', 'StockKeepingUnit', 'Price', 'Content');
	var $helpers = array('Html', 'Form');

	// AuthComponentの宣言
	var $components = array('Auth');

	function beforeFilter() {
		$this->Auth->userModel = 'Staff';
		$this->Auth->allow('productList');
		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');
		$this->set('user', $this->Auth->user());
		
		$userShop = $this->Product->getStaffShop($this->Auth->user('shop_id'));
		$this->set(compact('userShop'));	
	}

	function login() {
	}

	function logout() {
		$this->Session->setFlash('ログアウトしました。');
		$this->Auth->logout();
		$this->redirect(array('controller' => 'staffs', 'action' => 'index'));
	}

	function index() {
		$this->Product->recursive = 0;
		$this->set('products', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid Product', true));
			$this->redirect(array('action' => 'index'));
		}
		
//		$cond = array(
//			'ColorChip.material_id' => array($materialId),
//			'ColorChip.number' => array($record[6]),
//		);
//		$colorChip = $this->ColorChip->find('all', array(
//			'conditions' => $cond,
//		));
//		$this->set('colorchip', $colorChip);
		
		$cond = array(
			'ProductColorChip.product_id' => array($id),
		);

		$productColorChips = $this->ProductColorChip->find('all', array(
			'conditions' => $cond,
			'order' => array('ProductColorChip.material_id'),
		) );

		$this->set(compact('productColorChips'));
		$this->set('product', $this->Product->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Product->create();
			if ($this->Product->save($this->data)) {
				$this->Session->setFlash(__('The Product has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The Product could not be saved. Please, try again.', true));
			}
		}
		$seasons = $this->Product->Season->find('list');
		$groups = $this->Product->Group->find('list');
		$categories = $this->Product->Category->find('list');
		$this->set(compact('seasons', 'groups', 'categories'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Product', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Product->save($this->data)) {
				$this->Session->setFlash(__('The Product has been saved', true));
				$this->redirect(array('action' => 'view', $id));
			} else {
				$this->Session->setFlash(__('The Product could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Product->read(null, $id);
		}
		$seasons = $this->Product->Season->find('list');
		$groups = $this->Product->Group->find('list');
		$categories = $this->Product->Category->find('list');
		$this->set(compact('seasons', 'groups', 'categories'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Product', true));
			$this->redirect(array('action' => 'index'));
		}
		if ($this->Product->del($id)) {
			$this->Session->setFlash(__('Product deleted', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash(__('The Product could not be deleted. Please, try again.', true));
		$this->redirect(array('action' => 'index'));
	}

	function productList() {
		$this->autoRender = false;
		Configure::write('debug', 0);

//		echo $this->data;
		
//		exit();
//		$categoryId = $this->data['id'];
		$c = json_decode($this->data);
		$cond = array(
			'Product.season_id' => array(1),
			'Product.category_id' => array($c->{'id'}),
			'Product.delete_flg' => array(0),
			);
		$products = $this->Product->find('all', array(
			'conditions' => $cond,
			'order' => array('Product.name'),
		));
		
		foreach($products as $product) {		
			$productArray[] = array("id" => $product['Product']['id'],
									"name" => $product['Product']['name'],
									);
		}
		
		print json_encode($productArray);
		/* end */
	}

/*

delete from categories where created>'2012-05-01 00:00:00';
delete from groups where created>'2012-05-01 00:00:00';
delete from materials where created>'2012-05-01 00:00:00';
delete from colors where created>'2012-05-01 00:00:00';
delete from color_chips where created>'2012-05-01 00:00:00';
delete from products where created>'2012-05-01 00:00:00';
delete from product_color_chips where created>'2012-05-01 00:00:00';
delete from stock_keeping_units where created>'2012-05-01 00:00:00';

*/
	function csv($id = null) {
	
		set_time_limit(7200);
		
		$userLevel = $this->Auth->user('level');
		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "csv_main";
		} else if ( $userLevel == STAFF_USER ) {
//			$viewTemplate = "csv_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "csv_admin";
		}
		
		$this->set('seasonId', $id);
//		$seasonId = 3;

		if (!empty($this->data)) {

			$fileName = "/tmp/product_result.csv";

			$seasonId = $this->data['Product']['seasonId'];

			if ( $this->data['Product']['mode'] == 'confirm' ) {
				$tmp_file = $this->data['Product']['csvfile']['tmp_name'];
				if( is_uploaded_file($tmp_file) === true ) {
					copy($tmp_file, $fileName);
		            $csvData = file($fileName, FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);
		            
		            $cnt = 0;
		            $groupRank = 1;
		            $categoryRank = 1;
		            $colorRank = 1;
		            $materialRank = 1;
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue; //$valueが4の処理をスキップ
						}
						$record = split(",", $line);
//						$shopData = $this->Staff->SearchShop($record[0]);

						if ($record[0] == 'Women shoes') {
							$menuId = 1;
						} else if ($record[0] == 'Men Shoes') {
							$menuId = 3;						
						} else {
							$menuId = 2;						
						}

						//-- カテゴリーを抽出
						$category = array(
							"season_id" => $seasonId,
							'menu_id' => $menuId,
							"name" => $record[11],
							"rank" => $categoryRank,
						);
						$categoryData[] = $category;

						//-- グループを抽出
						$group = array(
							"season_id" => $seasonId,
							"menu_id" => $menuId,
							"name" => $record[2],
							"rank" => $groupRank,
						);
						$groupData[] = $group;
						
						//-- カラーチップの色を抽出
						$color = array(
							"season_id" => $seasonId,
							"menu_id" => $menuId,
							"name" => $record[9],
						);
						$colorData[] = $color;

						//-- 素材を抽出
						$material = array(
							"season_id" => $seasonId,
							"name" => $record[4],
							"description" => $record[8],
						);
						$materialData[] = $material;
												
	
						/*
						 *
						 *
						 */
												
						//-- categories
						$cond = array(
							'Category.season_id' => array( $seasonId ),
							'Category.menu_id' => array( $menuId ),
							'Category.name' => array( $record[11] ),
						);
						$c = $this->Product->Category->find('all', array(
							'conditions' => $cond
						));
						if ( count($c) == 0 ) {
							$this->Product->Category->create();
							$this->Product->Category->save($category);
							$categoryRank++;
						}
						
						//-- groups
						$cond = array(
							'Group.season_id' => array( $seasonId ),
							'Group.menu_id' => array( $menuId ),
							'Group.name' => array( $record[2] ),
						);
						$g = $this->Product->Group->find('all', array(
							'conditions' => $cond
						));
						if ( count($g) == 0 ) {
							$this->Product->Group->create();
							$this->Product->Group->save($group);
							$groupRank++;
						}

						//-- colors
						$cond = array(
							'Color.season_id' => array( $seasonId ),
							'Color.menu_id' => array( $menuId ),
							'Color.name' => array( $record[9] ),
						);
						$co = $this->Color->find('all', array(
							'conditions' => $cond
						));
						if ( count($co) == 0 ) {
							$this->Color->create();
							$this->Color->save($color);
							$colorRank++;
						}

						//-- materials
						$cond = array(
							'Material.season_id' => array( $seasonId ),
//							'Material.menu_id' => array( $menuId ),
							'Material.name' => array( $record[4] ),
						);
						$m = $this->Material->find('all', array(
							'conditions' => $cond
						));
						if ( count($m) == 0 ) {
							$this->Material->create();
							$this->Material->save($material);
							$materialRank++;
						}
					}

					/*
					 *
					 *
					 */
					$cnt = 0;
					//-- カラーチップを登録
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue; //$valueが4の処理をスキップ
						}
						$record = split(",", $line);
						
						$cond = array(
							'Material.season_id' => array($seasonId),
							'Material.name' => array($record[4]),
						);
						$material = $this->Material->find('first', array(
							'conditions' => $cond,
							'fields' => array('Material.id'),
						));
						
						$cond = array(
							'Color.season_id' => array($seasonId),
							'Color.name' => array($record[9]),
						);
						$color = $this->Color->find('first', array(
							'conditions' => $cond,
							'fields' => array('Color.id'),
						));

						$materialId = $material['Material']['id'];  //-- materials tableより
						if ( $color['Color']['id'] != "" ) {
							$colorId = $color['Color']['id'];  //-- color tableより
						} else {
							$colorId = 0;				
						}
						
						$cond = array(
							'ColorChip.season_id' => array($seasonId),
							'ColorChip.material_id' => array($materialId),
							'ColorChip.number' => array($record[5]),
						);
						$result = $this->ColorChip->find('all', array(
							'conditions' => $cond,
						));

						if ( count($result) == 0 ) {
						$color_chip = array(
//							"id" => $record[1],
							"season_id" => $seasonId,
							"material_id" => $materialId,
							"color_id" => $colorId,
							"number" => $record[5],
							"name" => $record[10],
//							"description" => $record[9],
						);
//						$colorChipData[] = $color_chip;

						$this->ColorChip->create();
						$this->ColorChip->save($color_chip);
						}
					}
					
					/*
					 *
					 *
					 */
					$cnt = 0;
					//-- 商品を登録
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue;
						}
						$record = split(",", $line);

						if ($record[0] == 'Women shoes') {
							$menuId = 1;
						} else if ($record[0] == 'Men Shoes') {
							$menuId = 3;						
						} else {
							$menuId = 2;						
						}

						/* カテゴリーIDを取得 */
						$cond = array(
							'Category.season_id' => array($seasonId),
							'Category.menu_id' => array($menuId),
							'Category.name' => array($record[11]),
						);
						$category = $this->Category->find('first', array(
							'conditions' => $cond,
							'fields' => array('Category.id'),
						));
						$categoryId = $category['Category']['id'];

						/*グループIDを取得*/
						$cond = array(
							'Group.season_id' => array($seasonId),
							'Group.menu_id' => array($menuId),
							'Group.name' => array($record[2]),
						);
						$group = $this->Group->find('first', array(
							'conditions' => $cond,
							'fields' => array('Group.id'),
						));
						$groupId = $group['Group']['id'];

						/* 商品を登録 */
						$product = array(
							"season_id" => $seasonId,
							"menu_id" => $menuId,
							"category_id" => $categoryId,
							"group_id" => $groupId,
							"name" => $record[3],
						);
//						$colorChipData[] = $color_chip;

						$cond = array(
							'Product.season_id' => array($seasonId),
							'Product.menu_id' => array($menuId),
							'Product.category_id' => array($categoryId),
							'Product.group_id' => array($groupId),
							'Product.name' => array($record[3]),
						);
						$result = $this->Product->find('all', array(
							'conditions' => $cond,
						));

						if ( count($result) == 0 ) {
							$this->Product->create();
							$this->Product->save($product);
						}
					}
					
					/*
					 *
					 *
					 */
					$cnt = 0;
					$pccCnt = 1;
					//-- 商品カラーチップを登録
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue; //$valueが4の処理をスキップ
						}
						$record = split(",", $line);

						//-- product nameからidを取得
						$cond = array(
							'Product.season_id' => array($seasonId),
							'Product.name' => array($record[3]),
						);
						$product = $this->Product->find('first', array(
							'conditions' => $cond,
							'fields' => array('Product.id'),
						));
						//--

						//-- material nameからidを取得
						$cond = array(
							'Material.season_id' => array($seasonId),
							'Material.name' => array($record[4]),
						);
						$material = $this->Material->find('first', array(
							'conditions' => $cond,
							'fields' => array('Material.id'),
						));
						//--
						
						//-- color_chip_id
						$cond = array(
							'ColorChip.season_id' => array($seasonId),
							'ColorChip.material_id' => array($material['Material']['id']),
							'ColorChip.number' => array($record[5]),
						);
						$colorChip = $this->ColorChip->find('first', array(
							'conditions' => $cond,
							'fields' => array('ColorChip.id'),
						));
						//--
						
						$cond = array(
							'ProductColorChip.product_id' => array($product['Product']['id']),
							'ProductColorChip.color_chip_id' => array($colorChip['ColorChip']['id']),
						);
						$result = $this->ProductColorChip->find('all', array(
							'conditions' => $cond,
						));

						if ( count($result) == 0 ) {
						$productColorChip = array(
							"product_id" => $product['Product']['id'],
							"material_id" => $material['Material']['id'],
							"color_chip_id" => $colorChip['ColorChip']['id'],
							"heel" => $record[12],
							"price" => $record[13],
							"product_image_number" => $seasonId.'_'.$record[1],
							"color_chip_image" => $record[6].'_'.$record[7],
							"rank" => $pccCnt,
						);
						$this->ProductColorChip->create();
						$this->ProductColorChip->save($productColorChip);
						$pccCnt++;
						}
					}
					
					/*
					 *
					 *
					 */
					$cnt = 0;
					$skuCnt = 1;
					//-- 商品SKUを登録
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue;
						}
						$record = split(",", $line);

						/* product nameよりidを取得*/
						$cond = array(
							'Product.season_id' => array($seasonId),
							'Product.name' => array($record[3]),
						);
						$product = $this->Product->find('first', array(
							'conditions' => $cond,
							'fields' => array('Product.id'),
						));
						$productId = $product['Product']['id'];
						
						/* material nameよりidを取得 */
						$cond = array(
							'Material.season_id' => array($seasonId),
							'Material.name' => array($record[4]),
						);
						$material = $this->Material->find('first', array(
							'conditions' => $cond,
							'fields' => array('Material.id'),
						));

						/* color chip material_idとnameよりcolor chip id を取得 */
						$cond = array(
							'ColorChip.season_id' => array($seasonId),
							'ColorChip.material_id' => array($material['Material']['id']),
							'ColorChip.number' => array($record[5]),
						);
						$colorChip = $this->ColorChip->find('first', array(
							'conditions' => $cond,
							'fields' => array('ColorChip.id'),
						));						
						$colorChipId = $colorChip['ColorChip']['id'];
						
						/* product idとcolor chip idでproduct color chip idを取得する */
						$cond = array(
							'ProductColorChip.product_id' => array($productId),
							'ProductColorChip.color_chip_id' => array($colorChipId),
						);
						$productColorChip = $this->ProductColorChip->find('first', array(
							'conditions' => $cond,
							'fields' => array('ProductColorChip.id'),
						));						
						$productColorChipId = $productColorChip['ProductColorChip']['id'];

						$sku = array(
//							"id" => $record[1],
							"product_color_chip_id" => $productColorChipId,
							"color_chip_id" => $colorChipId,
							"name" => $record[15],
							"heel" => $record[12],
							"size" => $record[14],
							"price" => $record[13],
							"quantity" => $record[16],
							"rank" => $skuCnt,
						);
//						$colorChipData[] = $color_chip;

						$this->StockKeepingUnit->create();
						$this->StockKeepingUnit->save($sku);
						$skuCnt++;
					}

					//-- StokKeepingUnit<-->ColorChip
					$this->set('categoryData', $categoryData);
					$this->set('groupData', $groupData);
//					$this->set('colorChipData', $colorData);
					$this->set('materialData', $materialData);
					$this->set('colorData', $colorData);
//					$this->set('colorChipData', $colorChipData);
					
//					$this->set('productData', $productData);
//					$this->set('error', $error);
					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = "csv_main_confirm";
					} else if ( $userLevel == STAFF_USER ) {
//						$viewTemplate = "csv_staff_register";
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = "csv_admin_confirm";
					}
				}
			} else if ( $this->data['Product']['mode'] == 'regsister' ) {
				$staff_id = $this->Auth->user('id');
				if ( $userLevel == HEAD_USER ) {
				
		            $csvData = file($fileName, FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);

//					foreach($csvData as $line){
//						$record = split(",", $line);
//			
//						$shopData = $this->Staff->SearchShop($record[0]);
//						$data = array(
//							"shop_id" => $shopData['Shop']['id'],
//							"staff_number" => $record[1],
//							"password" => $this->Auth->password($record[2]),
//							"name" => $record[3],
//							"furigana" => $record[4],
//							"email" => $record[5],
//							"level" => 2,
//							'delete_flg' => 0,
//							'creator_id' => $staff_id,
//							'updater_id' => $staff_id,
//						);
//						$this->Staff->create();
//						$this->Staff->save($data);
//					}
					$viewTemplate = "csv_main_register";
				} else if ( $userLevel == STAFF_USER ) {
//					$viewTemplate = "csv_staff_register";
				} else if ( $userLevel == SYSTEM_USER ) {
					$viewTemplate = "csv_admin_register";
				}
			}
		}
		$this->render($viewTemplate);
	}

	function colorChipCsv($id = null) {
	
		set_time_limit(7200);
		
		$userLevel = $this->Auth->user('level');
		if ( $userLevel == HEAD_USER ) {
			$viewTemplate = "color_chip_csv_main";
		} else if ( $userLevel == STAFF_USER ) {
//			$viewTemplate = "csv_staff";
		} else if ( $userLevel == SYSTEM_USER ) {
			$viewTemplate = "color_chip_csv_admin";
		}

		$this->set('seasonId', $id);
//		$seasonId = 3;

		if (!empty($this->data)) {

			$fileName = "/tmp/product_color_chip_result.csv";

			$seasonId = $this->data['Product']['seasonId'];

			if ( $this->data['Product']['mode'] == 'regsister' ) {
				$tmp_file = $this->data['Product']['csvfile']['tmp_name'];
				if( is_uploaded_file($tmp_file) === true ) {
					copy($tmp_file, $fileName);
					$csvData = file($fileName, FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES);
					$cnt = 0;
					$groupRank = 1;
					$categoryRank = 1;
					$colorRank = 1;
					$materialRank = 1;

					$resultProducts = array();
					foreach($csvData as $line){
						if( $cnt == 0 ){
							$cnt++;
							continue; //$valueが4の処理をスキップ
						}
						$record = split(",", $line);

						if ($record[0] == 'Women shoes') {
							$menuId = 1;
						} else if ($record[0] == 'Men Shoes') {
							$menuId = 3;
						} else {
							$menuId = 2;
						}

						//-- product nameからidを取得
						$cond = array(
							'Product.season_id' => array($seasonId),
							'Product.name' => array($record[3]),
						);
						$product = $this->Product->find('first', array(
							'conditions' => $cond,
							'fields' => array('Product.id'),
						));

						//-- material nameからidを取得
						$cond = array(
							'Material.season_id' => array($seasonId),
							'Material.name' => array($record[4]),
						);
						$material = $this->Material->find('first', array(
							'conditions' => $cond,
							'fields' => array('Material.id'),
						));

						//-- color_chip_id
						$cond = array(
							'ColorChip.season_id' => array($seasonId),
							'ColorChip.material_id' => array($material['Material']['id']),
							'ColorChip.number' => array($record[5]),
						);
						$colorChip = $this->ColorChip->find('first', array(
							'conditions' => $cond,
							'fields' => array('ColorChip.id'),
						));

						print $seasonId."-".$record[3]."-".$product['Product']['id']."<br>";
						print $seasonId."-".$record[4]."-".$material['Material']['id']."<br>";
						print $seasonId."-".$record[5]."-".$colorChip['ColorChip']['id']."<br>";

						$cond = array(
							'ProductColorChip.product_id' => array($product['Product']['id']),
							'ProductColorChip.material_id' => array($material['Material']['id']),
							'ProductColorChip.color_chip_id' => array($colorChip['ColorChip']['id']),
						);
						$result = $this->ProductColorChip->find('first', array(
							'conditions' => $cond,
						));

						if ( !empty($result['ProductColorChip']['id'])) {
							$resultProducts[] = array('result'=>'更新完了', 'product'=>$record[3]);
							$this->ProductColorChip->id = $result['ProductColorChip']['id'];
							$asd['ProductColorChip'] = array(
								"product_image_number" => $seasonId.'_'.$record[1],
								"color_chip_image" => $record[6].'_'.$record[7],
							);
							$this->ProductColorChip->save($asd);
						} else {
							$resultProducts[] = array('result'=>'未登録', 'product'=>$record[3]);
						}
					}

					if ( $userLevel == HEAD_USER ) {
						$viewTemplate = "color_chip_csv_main_confirm";
					} else if ( $userLevel == STAFF_USER ) {
//						$viewTemplate = "csv_staff_register";
					} else if ( $userLevel == SYSTEM_USER ) {
						$viewTemplate = "color_chip_csv_admin_register";
					}
					$this->set(compact('resultProducts'));
				}
			}
		}
		$this->render($viewTemplate);
	}

	function makePlist() {
		$this->autoRender = false;
//		Configure::write('debug', 0);
        $file = new File('/var/www/jp.nabeworks.sergiorossi/html/data/config_files/sergiorossi_2011_SS_00.plist', true);
        
        /*
         * START
         */
        $file->write('<?xml version="1.0" encoding="UTF-8"?>'."\n");
        $file->write('<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'."\n");
        $file->write('<plist version="1.0">'."\n");
        $file->write('<dict>'."\n");
        
		//-- DataBase
        $file->write('<key>database</key>'."\n");
        $file->write('<string>sergiorossi_2011_SS.sqlite</string>'."\n");

		//-- menuContent
/*        $file->write('<key>menuContent</key>'."\n");
        $file->write('<dict>'."\n");
        $file->write('<key>filename</key>'."\n");
        $file->write('<string>obj_2010fw_photo.jpg</string>'."\n");
        $file->write('<key>filetype</key>'."\n");
        $file->write('<string>img</string>'."\n");
        $file->write('</dict>'."\n");
*/        
        
        /* Contents */
		$cond = array(
			'Content.season_id' => array(1),
//			'Content.menu_id' => array(1),
			'Content.delete_flg' => array(0),
			);
		$contents = $this->Content->find('all', array(
			'conditions' => $cond,
//			'order' => array('Content.name'),
			));
		foreach($contents as $content) {
			$file->write("<key>{$content['Content']['name']}</key>\n");
			$file->write('<dict>'."\n");
			$file->write('<key>filename</key>'."\n");
			$file->write("<string>{$content['Content']['filename']}</string>\n");
			$file->write('<key>filetype</key>'."\n");
			$file->write("<string>{$content['Content']['filetype']}</string>\n");
			$file->write('</dict>'."\n");
		}
        /* end */
        

		//-- Womens Shoes
		$file->write('<key>lady</key>'."\n");
		$file->write('<array>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>0</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string></string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>ALL VIEW</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>1</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>ladyCategory</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>CATEGORY</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<true/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>2</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>ladyGroup</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>GROUP</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>3</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>ladyColor</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>COLOR</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>4</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>ladyHeel</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>HEEL HEIGHT</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('</array>'."\n");

        //-- Womens Content
/*		$file->write('<key>ladyContent</key>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>filename</key>'."\n");
		$file->write('<string>obj_2010fw_shoe_photo.jpg</string>'."\n");
		$file->write('<key>filetype</key>'."\n");
		$file->write('<string>img</string>'."\n");
		$file->write('</dict>'."\n");
*/

		//-- Womens CATEGORY
		$cond = array(
			'Category.season_id' => array(1),
			'Category.menu_id' => array(1),
			'Category.delete_flg' => array(0),
			);
		$categories = $this->Category->find('all', array(
			'conditions' => $cond,
			'order' => array('Category.name'),
			));
		$file->write('<key>ladyCategory</key>'."\n");
		$file->write('<array>'."\n");
		foreach($categories as $category) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$category['Category']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$category['Category']['name']}</string>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		//-- Womens GROUP
		$cond = array(
			'Group.season_id' => array(1),
			'Group.menu_id' => array(1),
			'Group.delete_flg' => array(0),
			);
		$groups = $this->Group->find('all', array(
			'conditions' => $cond,
			'order' => array('Group.name'),
		));
		$file->write('<key>ladyGroup</key>'."\n");
		$file->write('<array>'."\n");
		foreach($groups as $group) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$group['Group']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$group['Group']['name']}</string>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		//-- Womens COLOR
		$cond = array(
			'Color.season_id' => array(1),
			'Color.menu_id' => array(1),
			'Color.delete_flg' => array(0),
			);
		$colors = $this->Color->find('all', array(
			'conditions' => $cond,
			'order' => array('Color.rank'),
		));
		$file->write('<key>ladyColor</key>'."\n");
		$file->write('<array>'."\n");
		foreach($colors as $color) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$color['Color']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$color['Color']['name']}</string>\n");
			$file->write("<key>r</key>\n");
			$file->write("<string>{$color['Color']['red']}</string>\n");
			$file->write("<key>g</key>\n");
			$file->write("<string>{$color['Color']['green']}</string>\n");
			$file->write("<key>b</key>\n");
			$file->write("<string>{$color['Color']['bule']}</string>\n");
			
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		//-- Womens HEEL
		$option = array(
			'fields' => 'DISTINCT ProductColorChip.heel',		
			'order' => array(
			'ProductColorChip.heel' => 'asc'
			)
		);
		$this->ProductColorChip->recursive = -1;
		$productColorChips = $this->ProductColorChip->find('all', $option);
		$file->write('<key>ladyHeel</key>'."\n");
		$file->write('<array>'."\n");
		$heelCnt = 1;
		foreach($productColorChips as $productColorChip) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$heelCnt}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$productColorChip['ProductColorChip']['heel']}</string>\n");
			$file->write('</dict>'."\n");
			$heelCnt++;
		}
		$file->write('</array>'."\n");

		//-- Accessories
		$file->write('<key>bag</key>'."\n");
		$file->write('<array>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>0</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string></string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>ALL VIEW</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>1</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>bagCategory</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>CATEGORY</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>2</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>bagGroup</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>GROUP</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('</array>'."\n");

		//-- Accessories Content
/*		$file->write('<key>bagContent</key>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>filename</key>'."\n");
		$file->write('<string>obj_2010fw_shoe_photo.jpg</string>'."\n");
		$file->write('<key>filetype</key>'."\n");
		$file->write('<string>img</string>'."\n");
		$file->write('</dict>'."\n");
*/

		//-- Accessories CATEGORY
		$cond = array(
			'Category.season_id' => array(1),
			'Category.menu_id' => array(2),
			'Category.delete_flg' => array(0),
			);
		$categories = $this->Category->find('all', array(
			'conditions' => $cond,
			'order' => array('Category.name'),
		));
		$file->write('<key>bagCategory</key>'."\n");
		$file->write('<array>'."\n");
		foreach($categories as $category) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$category['Category']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$category['Category']['name']}</string>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		//-- Accessories GROUP
		$cond = array(
			'Group.season_id' => array(1),
			'Group.menu_id' => array(2),
			'Group.delete_flg' => array(0),
			);
		$groups = $this->Group->find('all', array(
			'conditions' => $cond,
			'order' => array('Group.name'),
		));
		$file->write('<key>bagGroup</key>'."\n");
		$file->write('<array>'."\n");
		foreach($groups as $group) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$group['Group']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$group['Group']['name']}</string>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		/*
		 * Mens Shoes
		 */
		$file->write('<key>mens</key>'."\n");
		$file->write('<array>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>0</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string></string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>ALL VIEW</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>1</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>mensCategory</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>CATEGORY</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>id</key>'."\n");
		$file->write('<integer>2</integer>'."\n");
		$file->write('<key>key</key>'."\n");
		$file->write('<string>mensGroup</string>'."\n");
		$file->write('<key>name</key>'."\n");
		$file->write('<string>GROUP</string>'."\n");
		$file->write('<key>price</key>'."\n");
		$file->write('<false/>'."\n");
		$file->write('</dict>'."\n");
		$file->write('</array>'."\n");

		//-- Mens Content
		$file->write('<key>mensContent</key>'."\n");
		$file->write('<dict>'."\n");
		$file->write('<key>filename</key>'."\n");
		$file->write('<string>obj_2010fw_shoe_photo.jpg</string>'."\n");
		$file->write('<key>filetype</key>'."\n");
		$file->write('<string>img</string>'."\n");
		$file->write('</dict>'."\n");

		//-- Mens CATEGORY
		$cond = array(
			'Category.season_id' => array(1),
			'Category.menu_id' => array(3),
			'Category.delete_flg' => array(0),
			);
		$categories = $this->Category->find('all', array(
			'conditions' => $cond,
			'order' => array('Category.name'),
		));
		$file->write('<key>mensCategory</key>'."\n");
		$file->write('<array>'."\n");
		foreach($categories as $category) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$category['Category']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$category['Category']['name']}</string>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		//-- Mens GROUP
		$cond = array(
			'Group.season_id' => array(1),
			'Group.menu_id' => array(3),
			'Group.delete_flg' => array(0),
			);
		$groups = $this->Group->find('all', array(
			'conditions' => $cond,
			'order' => array('Group.name'),
		));
		$file->write('<key>mensGroup</key>'."\n");
		$file->write('<array>'."\n");
		foreach($groups as $group) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$group['Group']['id']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$group['Group']['name']}</string>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");

		/*
		 * Price
		 */
		$cond = array(
			'Price.season_id' => array(1),
			'Price.menu_id' => array(1),
			'Price.delete_flg' => array(0),
			);
		$prices = $this->Price->find('all', array(
			'conditions' => $cond,
			'order' => array('Price.rank'),
		));
		$file->write('<key>price</key>'."\n");
		$file->write('<array>'."\n");
		foreach($prices as $price) {
			$file->write('<dict>'."\n");
			$file->write('<key>id</key>'."\n");
			$file->write("<integer>{$price['Price']['id']}</integer>\n");
			$file->write('<key>lowerPrice</key>'."\n");
			$file->write("<integer>{$price['Price']['lower_price']}</integer>\n");
			$file->write('<key>name</key>'."\n");
			$file->write("<string>{$price['Price']['name']}</string>\n");
			$file->write('<key>upperPrice</key>'."\n");
			$file->write("<integer>{$price['Price']['upper_price']}</integer>\n");
			$file->write('</dict>'."\n");
		}
		$file->write('</array>'."\n");


		/*
		 * END
		 */
        $file->write('</dict>'."\n");
        $file->write('</plist>');

        $file->close();
        $this->output = null;

	}

	function makeSqlite() {
//		$this->autoRender = false;
//		Configure::write('debug', 0);
		
//		$cond = array(
//			'Season.delete_flg' => array(0),
//			);
//		$seasons = $this->Season->find('all', array(
//			'conditions' => $cond,
//		));

//		foreach($seasons as $season){
//			echo $season['Season']['name'];		
			
			$sqlFilename = "sergiorossi_db.sql";
			$sqliteFilename = "sergiorossi_db.sqlite";
			
	        $file = new File(SQLFILE_PATH.$sqlFilename, true);

			/* products table */
			$file->write('DROP TABLE IF EXISTS "products"; '."\n");
			$file->write('CREATE TABLE "products" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"name" VARCHAR , '."\n");
			$file->write('"season_id" INTEGER NOT NULL , '."\n");
			$file->write('"menu_id" INTEGER NOT NULL , '."\n");
			$file->write('"group_id" INTEGER NOT NULL , '."\n");
			$file->write('"category_id" INTEGER NOT NULL '."\n");
			$file->write('); '."\n");

			$cond = array(
//				'Product.season_id' => array($season['Season']['id']),
				'Product.delete_flg' => array(0),
				);
			$products = $this->Product->find('all', array(
				'conditions' => $cond,
			));
	
			foreach($products as $product){
				$file->write("INSERT INTO `products` VALUES ({$product['Product']['id']},'{$product['Product']['name']}',{$product['Product']['season_id']},{$product['Product']['menu_id']},{$product['Product']['group_id']},{$product['Product']['category_id']});\n");
			}

			/* product_color_chips table */
			$file->write("\n\n");
			$file->write('DROP TABLE IF EXISTS "product_color_chips"; '."\n");
			$file->write('CREATE TABLE "product_color_chips" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"product_id" INTEGER NOT NULL , '."\n");
			$file->write('"season_id" INTEGER NOT NULL , '."\n");
			$file->write('"menu_id" INTEGER NOT NULL , '."\n");
			$file->write('"group_id" INTEGER NOT NULL , '."\n");
			$file->write('"category_id" INTEGER NOT NULL , '."\n");
			$file->write('"material_id" INTEGER NOT NULL , '."\n");
			$file->write('"color_chip_id" INTEGER NOT NULL , '."\n");
			$file->write('"color_id" INTEGER NOT NULL , '."\n");
			$file->write('"name" VARCHAR , '."\n");
			$file->write('"group_name" VARCHAR , '."\n");
			$file->write('"category_name" VARCHAR , '."\n");
			$file->write('"material_name" VARCHAR , '."\n");
			$file->write('"material_description" VARCHAR , '."\n");
			$file->write('"color_chip_name" VARCHAR , '."\n");
			$file->write('"heel" VARCHAR , '."\n");
			$file->write('"price" INTEGER NOT NULL , '."\n");
			$file->write('"product_image_number" VARCHAR , '."\n");
			$file->write('"color_chip_image" VARCHAR , '."\n");
			$file->write('"rank" INTEGER NOT NULL , '."\n");
			$file->write('"stock_flg" INTEGER NOT NULL '."\n");
			$file->write('); '."\n");

			$productColorChips = $this->ProductColorChip->query('SELECT Product.id, Product.season_id, Product.menu_id, Product.group_id, Product.category_id, ProductColorChip.id, ProductColorChip.material_id, ProductColorChip.color_chip_id, ColorChip.color_id, Product.name, ProductColorChip.heel, ProductColorChip.price, ProductColorChip.color_chip_image, ProductColorChip.product_image_number, ProductColorChip.rank, Category.name, Group.name, Material.name, Material.description, ColorChip.name FROM products AS Product, product_color_chips AS ProductColorChip, materials AS Material, color_chips AS ColorChip, categories AS Category, groups AS `Group` WHERE Product.id=ProductColorChip.product_id AND Product.category_id=Category.id AND Product.group_id=Group.id AND ProductColorChip.material_id=Material.id AND ProductColorChip.color_chip_id=ColorChip.id AND ProductColorChip.delete_flg=0');
	
			foreach($productColorChips as $productColorChip){
				$productColorChipCategoryName = str_replace ("'", "''", $productColorChip['Category']['name']);
				$productColorChipMaterialName = str_replace ("'", "''", $productColorChip['Material']['name']);
				$productColorChipMaterialDescription = str_replace ("'", "''", $productColorChip['Material']['description']);
				$productColorChipColorChipName = str_replace ("'", "''", $productColorChip['ColorChip']['name']);
				$file->write("INSERT INTO `product_color_chips` VALUES ({$productColorChip['ProductColorChip']['id']},{$productColorChip['Product']['id']},{$productColorChip['Product']['season_id']},{$productColorChip['Product']['menu_id']},{$productColorChip['Product']['group_id']},{$productColorChip['Product']['category_id']},{$productColorChip['ProductColorChip']['material_id']},{$productColorChip['ProductColorChip']['color_chip_id']},{$productColorChip['ColorChip']['color_id']},'{$productColorChip['Product']['name']}','{$productColorChip['Group']['name']}','{$productColorChipCategoryName}','{$productColorChipMaterialName}','{$productColorChipMaterialDescription}','{$productColorChipColorChipName}','{$productColorChip['ProductColorChip']['heel']}',{$productColorChip['ProductColorChip']['price']},'{$productColorChip['ProductColorChip']['product_image_number']}','{$productColorChip['ProductColorChip']['color_chip_image']}',{$productColorChip['ProductColorChip']['rank']},0);\n");
			}

			/* color_chips table */
			$file->write("\n\n");
			$file->write('DROP TABLE IF EXISTS "color_chips"; '."\n");
			$file->write('CREATE TABLE "color_chips" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"color_id" INTEGER NOT NULL , '."\n");
			$file->write('"material_id" INTEGER NOT NULL , '."\n");
			$file->write('"material_name" VARCHAR , '."\n");
			$file->write('"material_description" VARCHAR , '."\n");
			$file->write('"number" VARCHAR , '."\n");
			$file->write('"name" VARCHAR '."\n");
			$file->write('); '."\n");
			
			$cond = array(
//				'ColorChip.season_id' => array($season['Season']['id']),
				'ColorChip.delete_flg' => array(0),
				);
			$colorChips = $this->ColorChip->find('all', array(
				'conditions' => $cond,
			));
			foreach($colorChips as $colorChip){
				$colorChipMaterialName = str_replace ("'", "''", $colorChip['Material']['name']);
				$colorChipMaterialDescription = str_replace ("'", "''", $colorChip['Material']['description']);
				$colorChipColorChipName = str_replace ("'", "''", $colorChip['ColorChip']['name']);				
				$file->write("INSERT INTO `color_chips` VALUES ({$colorChip['ColorChip']['id']},{$colorChip['ColorChip']['color_id']},{$colorChip['Material']['id']},'{$colorChipMaterialName}','{$colorChipMaterialDescription}','{$colorChip['ColorChip']['number']}','{$colorChipColorChipName}');\n");
			}


			/* stock_keeping_units table 
			$file->write("\n\n");
			$file->write('DROP TABLE IF EXISTS "stock_keeping_units"; '."\n");
			$file->write('CREATE TABLE "stock_keeping_units" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"product_color_chip_id" INTEGER NOT NULL , '."\n");
			$file->write('"name" VARCHAR , '."\n");
			$file->write('"heel" VARCHAR , '."\n");
			$file->write('"size" VARCHAR , '."\n");
			$file->write('"price" decimal(10,0) , '."\n");
			$file->write('"quantity" decimal(10,0) , '."\n");
			$file->write('"rank" INTEGER NOT NULL '."\n");
			$file->write('); '."\n");

//			$cond = array(
//				'Product.delete_flg' => array(0),
//				);
//			$stockKeepingUnits = $this->StockKeepingUnit->find('all', array(
//				'conditions' => $cond,
//			));
			
			$stockKeepingUnits = $this->StockKeepingUnit->query('SELECT StockKeepingUnit.id, StockKeepingUnit.product_color_chip_id, StockKeepingUnit.name, StockKeepingUnit.heel, StockKeepingUnit.size, StockKeepingUnit.price, StockKeepingUnit.quantity, StockKeepingUnit.rank FROM products AS Product, product_color_chips AS ProductColorChip, stock_keeping_units AS StockKeepingUnit WHERE Product.id=ProductColorChip.product_id AND ProductColorChip.id=StockKeepingUnit.product_color_chip_id');
			
			foreach($stockKeepingUnits as $stockKeepingUnit){
				$file->write("INSERT INTO `stock_keeping_units` VALUES ({$stockKeepingUnit['StockKeepingUnit']['id']},{$stockKeepingUnit['StockKeepingUnit']['product_color_chip_id']},'{$stockKeepingUnit['StockKeepingUnit']['name']}','{$stockKeepingUnit['StockKeepingUnit']['heel']}','{$stockKeepingUnit['StockKeepingUnit']['size']}',{$stockKeepingUnit['StockKeepingUnit']['price']},{$stockKeepingUnit['StockKeepingUnit']['quantity']},{$stockKeepingUnit['StockKeepingUnit']['rank']});\n");
			}
*/
			/*  */
			$sqliteCmd = SQLITE3." ".SQLITE_PATH.$sqliteFilename.' < ' .SQLFILE_PATH.$sqlFilename;
//			print $sqliteCmd;
			$output = `$sqliteCmd`;
//		}
		
// 		$this->Session->setFlash(__('Compalte', true));
// 		$this->redirect(array('controller' => 'seasons', 'action' => 'index'));

//		exit();
		
	}


	function makeSqlite2() {
//		$this->autoRender = false;
//		Configure::write('debug', 0);
		
//		$cond = array(
//			'Season.delete_flg' => array(0),
//			);
//		$seasons = $this->Season->find('all', array(
//			'conditions' => $cond,
//		));

//		foreach($seasons as $season){
//			echo $season['Season']['name'];		
			
			$sqlFilename = "sergiorossi_db.sql";
			$sqliteFilename = "sergiorossi_db.sqlite";
			
	        $file = new File(SQLFILE_PATH.$sqlFilename, true);

			/* products table 
			$file->write('DROP TABLE IF EXISTS "products"; '."\n");
			$file->write('CREATE TABLE "products" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"name" VARCHAR , '."\n");
			$file->write('"season_id" INTEGER NOT NULL , '."\n");
			$file->write('"menu_id" INTEGER NOT NULL , '."\n");
			$file->write('"group_id" INTEGER NOT NULL , '."\n");
			$file->write('"category_id" INTEGER NOT NULL '."\n");
			$file->write('); '."\n");

			$cond = array(
//				'Product.season_id' => array($season['Season']['id']),
				'Product.delete_flg' => array(0),
				);
			$products = $this->Product->find('all', array(
				'conditions' => $cond,
			));
	
			foreach($products as $product){
				$file->write("INSERT INTO `products` VALUES ({$product['Product']['id']},'{$product['Product']['name']}',{$product['Product']['season_id']},{$product['Product']['menu_id']},{$product['Product']['group_id']},{$product['Product']['category_id']});\n");
			}
*/
			/* product_color_chips table 
			$file->write("\n\n");
			$file->write('DROP TABLE IF EXISTS "product_color_chips"; '."\n");
			$file->write('CREATE TABLE "product_color_chips" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"product_id" INTEGER NOT NULL , '."\n");
			$file->write('"season_id" INTEGER NOT NULL , '."\n");
			$file->write('"menu_id" INTEGER NOT NULL , '."\n");
			$file->write('"group_id" INTEGER NOT NULL , '."\n");
			$file->write('"category_id" INTEGER NOT NULL , '."\n");
			$file->write('"material_id" INTEGER NOT NULL , '."\n");
			$file->write('"color_chip_id" INTEGER NOT NULL , '."\n");
			$file->write('"color_id" INTEGER NOT NULL , '."\n");
			$file->write('"name" VARCHAR , '."\n");
			$file->write('"group_name" VARCHAR , '."\n");
			$file->write('"category_name" VARCHAR , '."\n");
			$file->write('"material_name" VARCHAR , '."\n");
			$file->write('"material_description" VARCHAR , '."\n");
			$file->write('"color_chip_name" VARCHAR , '."\n");
			$file->write('"heel" VARCHAR , '."\n");
			$file->write('"price" INTEGER NOT NULL , '."\n");
			$file->write('"product_image_number" VARCHAR , '."\n");
			$file->write('"color_chip_image" VARCHAR , '."\n");
			$file->write('"rank" INTEGER NOT NULL , '."\n");
			$file->write('"stock_flg" INTEGER NOT NULL '."\n");
			$file->write('); '."\n");

			$productColorChips = $this->ProductColorChip->query('SELECT Product.id, Product.season_id, Product.menu_id, Product.group_id, Product.category_id, ProductColorChip.id, ProductColorChip.material_id, ProductColorChip.color_chip_id, ColorChip.color_id, Product.name, ProductColorChip.heel, ProductColorChip.price, ProductColorChip.color_chip_image, ProductColorChip.product_image_number, ProductColorChip.rank, Category.name, Group.name, Material.name, Material.description, ColorChip.name FROM products AS Product, product_color_chips AS ProductColorChip, materials AS Material, color_chips AS ColorChip, categories AS Category, groups AS `Group` WHERE Product.id=ProductColorChip.product_id AND Product.category_id=Category.id AND Product.group_id=Group.id AND ProductColorChip.material_id=Material.id AND ProductColorChip.color_chip_id=ColorChip.id AND ProductColorChip.delete_flg=0');
	
			foreach($productColorChips as $productColorChip){
				$productColorChipCategoryName = str_replace ("'", "''", $productColorChip['Category']['name']);
				$productColorChipMaterialName = str_replace ("'", "''", $productColorChip['Material']['name']);
				$productColorChipMaterialDescription = str_replace ("'", "''", $productColorChip['Material']['description']);
				$productColorChipColorChipName = str_replace ("'", "''", $productColorChip['ColorChip']['name']);
				$file->write("INSERT INTO `product_color_chips` VALUES ({$productColorChip['ProductColorChip']['id']},{$productColorChip['Product']['id']},{$productColorChip['Product']['season_id']},{$productColorChip['Product']['menu_id']},{$productColorChip['Product']['group_id']},{$productColorChip['Product']['category_id']},{$productColorChip['ProductColorChip']['material_id']},{$productColorChip['ProductColorChip']['color_chip_id']},{$productColorChip['ColorChip']['color_id']},'{$productColorChip['Product']['name']}','{$productColorChip['Group']['name']}','{$productColorChipCategoryName}','{$productColorChipMaterialName}','{$productColorChipMaterialDescription}','{$productColorChipColorChipName}','{$productColorChip['ProductColorChip']['heel']}',{$productColorChip['ProductColorChip']['price']},'{$productColorChip['ProductColorChip']['product_image_number']}','{$productColorChip['ProductColorChip']['color_chip_image']}',{$productColorChip['ProductColorChip']['rank']},0);\n");
			}
*/
			/* color_chips table 
			$file->write("\n\n");
			$file->write('DROP TABLE IF EXISTS "color_chips"; '."\n");
			$file->write('CREATE TABLE "color_chips" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"color_id" INTEGER NOT NULL , '."\n");
			$file->write('"material_id" INTEGER NOT NULL , '."\n");
			$file->write('"material_name" VARCHAR , '."\n");
			$file->write('"material_description" VARCHAR , '."\n");
			$file->write('"number" VARCHAR , '."\n");
			$file->write('"name" VARCHAR '."\n");
			$file->write('); '."\n");
			
			$cond = array(
//				'ColorChip.season_id' => array($season['Season']['id']),
				'ColorChip.delete_flg' => array(0),
				);
			$colorChips = $this->ColorChip->find('all', array(
				'conditions' => $cond,
			));
			foreach($colorChips as $colorChip){
				$colorChipMaterialName = str_replace ("'", "''", $colorChip['Material']['name']);
				$colorChipMaterialDescription = str_replace ("'", "''", $colorChip['Material']['description']);
				$colorChipColorChipName = str_replace ("'", "''", $colorChip['ColorChip']['name']);				
				$file->write("INSERT INTO `color_chips` VALUES ({$colorChip['ColorChip']['id']},{$colorChip['ColorChip']['color_id']},{$colorChip['Material']['id']},'{$colorChipMaterialName}','{$colorChipMaterialDescription}','{$colorChip['ColorChip']['number']}','{$colorChipColorChipName}');\n");
			}
*/
			/* stock_keeping_units table */
			$file->write("\n\n");
			$file->write('DROP TABLE IF EXISTS "stock_keeping_units"; '."\n");
			$file->write('CREATE TABLE "stock_keeping_units" ( '."\n");
			$file->write('"id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , '."\n");
			$file->write('"product_color_chip_id" INTEGER NOT NULL , '."\n");
			$file->write('"name" VARCHAR , '."\n");
			$file->write('"heel" VARCHAR , '."\n");
			$file->write('"size" VARCHAR , '."\n");
			$file->write('"price" decimal(10,0) , '."\n");
			$file->write('"quantity" decimal(10,0) , '."\n");
			$file->write('"rank" INTEGER NOT NULL '."\n");
			$file->write('); '."\n");

//			$cond = array(
//				'Product.delete_flg' => array(0),
//				);
//			$stockKeepingUnits = $this->StockKeepingUnit->find('all', array(
//				'conditions' => $cond,
//			));
			
			$stockKeepingUnits = $this->StockKeepingUnit->query('SELECT StockKeepingUnit.id, StockKeepingUnit.product_color_chip_id, StockKeepingUnit.name, StockKeepingUnit.heel, StockKeepingUnit.size, StockKeepingUnit.price, StockKeepingUnit.quantity, StockKeepingUnit.rank FROM products AS Product, product_color_chips AS ProductColorChip, stock_keeping_units AS StockKeepingUnit WHERE Product.id=ProductColorChip.product_id AND ProductColorChip.id=StockKeepingUnit.product_color_chip_id');
			
			foreach($stockKeepingUnits as $stockKeepingUnit){
				$file->write("INSERT INTO `stock_keeping_units` VALUES ({$stockKeepingUnit['StockKeepingUnit']['id']},{$stockKeepingUnit['StockKeepingUnit']['product_color_chip_id']},'{$stockKeepingUnit['StockKeepingUnit']['name']}','{$stockKeepingUnit['StockKeepingUnit']['heel']}','{$stockKeepingUnit['StockKeepingUnit']['size']}',{$stockKeepingUnit['StockKeepingUnit']['price']},{$stockKeepingUnit['StockKeepingUnit']['quantity']},{$stockKeepingUnit['StockKeepingUnit']['rank']});\n");
			}

			/*  */
			$sqliteCmd = SQLITE3." ".SQLITE_PATH.$sqliteFilename.' < ' .SQLFILE_PATH.$sqlFilename;
//			print $sqliteCmd;
			$output = `$sqliteCmd`;
//		}
		
//		$this->Session->setFlash(__('Compalte', true));
//		$this->redirect(array('controller' => 'seasons', 'action' => 'index'));

//		exit();
		
	}

}
?>