<?php 
/* SVN FILE: $Id$ */
/* Demand Test cases generated on: 2010-11-29 15:41:44 : 1291012904*/
App::import('Model', 'Demand');

class DemandTestCase extends CakeTestCase {
	var $Demand = null;
	var $fixtures = array('app.demand');

	function startTest() {
		$this->Demand =& ClassRegistry::init('Demand');
	}

	function testDemandInstance() {
		$this->assertTrue(is_a($this->Demand, 'Demand'));
	}

	function testDemandFind() {
		$this->Demand->recursive = -1;
		$results = $this->Demand->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Demand' => array(
			'id' => 1,
			'shop_id' => 1,
			'staff_id' => 1,
			'shop_name' => 'Lorem ipsum dolor sit amet',
			'staff_name' => 'Lorem ipsum dolor sit amet',
			'subject' => 'Lorem ipsum dolor sit amet',
			'body' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida,phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam,vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit,feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-11-29 15:41:44',
			'modified' => '2010-11-29 15:41:44'
		));
		$this->assertEqual($results, $expected);
	}
}
?>