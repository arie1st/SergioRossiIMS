<?php 
/* SVN FILE: $Id$ */
/* Knowhow Test cases generated on: 2010-10-21 19:35:14 : 1287657314*/
App::import('Model', 'Knowhow');

class KnowhowTestCase extends CakeTestCase {
	var $Knowhow = null;
	var $fixtures = array('app.knowhow', 'app.staff');

	function startTest() {
		$this->Knowhow =& ClassRegistry::init('Knowhow');
	}

	function testKnowhowInstance() {
		$this->assertTrue(is_a($this->Knowhow, 'Knowhow'));
	}

	function testKnowhowFind() {
		$this->Knowhow->recursive = -1;
		$results = $this->Knowhow->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Knowhow' => array(
			'id' => 1,
			'shop_id' => 1,
			'staff_id' => 1,
			'shop_name' => 'Lorem ipsum dolor sit amet',
			'staff_name' => 'Lorem ipsum dolor sit amet',
			'subject' => 'Lorem ipsum dolor sit amet',
			'body' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida,phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam,vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit,feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'approve_flg' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-21 19:35:12',
			'modified' => '2010-10-21 19:35:12'
		));
		$this->assertEqual($results, $expected);
	}
}
?>