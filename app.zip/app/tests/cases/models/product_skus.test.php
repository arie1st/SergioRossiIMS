<?php 
/* SVN FILE: $Id$ */
/* ProductSkus Test cases generated on: 2010-10-26 15:31:34 : 1288074694*/
App::import('Model', 'ProductSkus');

class ProductSkusTestCase extends CakeTestCase {
	var $ProductSkus = null;
	var $fixtures = array('app.product_skus', 'app.product');

	function startTest() {
		$this->ProductSkus =& ClassRegistry::init('ProductSkus');
	}

	function testProductSkusInstance() {
		$this->assertTrue(is_a($this->ProductSkus, 'ProductSkus'));
	}

	function testProductSkusFind() {
		$this->ProductSkus->recursive = -1;
		$results = $this->ProductSkus->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('ProductSkus' => array(
			'id' => 1,
			'product_id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'heel' => 1,
			'size' => 'Lorem ipsum dolor sit amet',
			'price' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-26 15:31:34',
			'modified' => '2010-10-26 15:31:34'
		));
		$this->assertEqual($results, $expected);
	}
}
?>