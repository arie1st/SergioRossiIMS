<?php 
/* SVN FILE: $Id$ */
/* ProductColorChip Test cases generated on: 2010-11-05 16:35:23 : 1288942523*/
App::import('Model', 'ProductColorChip');

class ProductColorChipTestCase extends CakeTestCase {
	var $ProductColorChip = null;
	var $fixtures = array('app.product_color_chip', 'app.product', 'app.color_chip');

	function startTest() {
		$this->ProductColorChip =& ClassRegistry::init('ProductColorChip');
	}

	function testProductColorChipInstance() {
		$this->assertTrue(is_a($this->ProductColorChip, 'ProductColorChip'));
	}

	function testProductColorChipFind() {
		$this->ProductColorChip->recursive = -1;
		$results = $this->ProductColorChip->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('ProductColorChip' => array(
			'id' => 1,
			'product_id' => 1,
			'color_chip_id' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-11-05 16:35:21',
			'modified' => '2010-11-05 16:35:21'
		));
		$this->assertEqual($results, $expected);
	}
}
?>