<?php 
/* SVN FILE: $Id$ */
/* City Test cases generated on: 2010-10-20 15:37:29 : 1287556649*/
App::import('Model', 'City');

class CityTestCase extends CakeTestCase {
	var $City = null;
	var $fixtures = array('app.city', 'app.shop');

	function startTest() {
		$this->City =& ClassRegistry::init('City');
	}

	function testCityInstance() {
		$this->assertTrue(is_a($this->City, 'City'));
	}

	function testCityFind() {
		$this->City->recursive = -1;
		$results = $this->City->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('City' => array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'created' => '2010-10-20 15:37:27',
			'modified' => '2010-10-20 15:37:27'
		));
		$this->assertEqual($results, $expected);
	}
}
?>