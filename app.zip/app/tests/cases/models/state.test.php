<?php 
/* SVN FILE: $Id$ */
/* State Test cases generated on: 2010-11-29 13:15:28 : 1291004128*/
App::import('Model', 'State');

class StateTestCase extends CakeTestCase {
	var $State = null;
	var $fixtures = array('app.state', 'app.knowhow');

	function startTest() {
		$this->State =& ClassRegistry::init('State');
	}

	function testStateInstance() {
		$this->assertTrue(is_a($this->State, 'State'));
	}

	function testStateFind() {
		$this->State->recursive = -1;
		$results = $this->State->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('State' => array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-11-29 13:15:28',
			'modified' => '2010-11-29 13:15:28'
		));
		$this->assertEqual($results, $expected);
	}
}
?>