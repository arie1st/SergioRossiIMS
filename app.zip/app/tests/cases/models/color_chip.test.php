<?php 
/* SVN FILE: $Id$ */
/* ColorChip Test cases generated on: 2010-10-26 15:26:04 : 1288074364*/
App::import('Model', 'ColorChip');

class ColorChipTestCase extends CakeTestCase {
	var $ColorChip = null;
	var $fixtures = array('app.color_chip', 'app.material');

	function startTest() {
		$this->ColorChip =& ClassRegistry::init('ColorChip');
	}

	function testColorChipInstance() {
		$this->assertTrue(is_a($this->ColorChip, 'ColorChip'));
	}

	function testColorChipFind() {
		$this->ColorChip->recursive = -1;
		$results = $this->ColorChip->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('ColorChip' => array(
			'id' => 1,
			'material_id' => 1,
			'color_id' => 1,
			'number' => 'Lorem ipsum dolor sit amet',
			'name' => 'Lorem ipsum dolor sit amet',
			'description' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida,phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam,vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit,feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'file_name' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-26 15:26:04',
			'modified' => '2010-10-26 15:26:04'
		));
		$this->assertEqual($results, $expected);
	}
}
?>