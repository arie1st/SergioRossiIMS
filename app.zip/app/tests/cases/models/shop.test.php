<?php 
/* SVN FILE: $Id$ */
/* Shop Test cases generated on: 2010-10-21 19:33:58 : 1287657238*/
App::import('Model', 'Shop');

class ShopTestCase extends CakeTestCase {
	var $Shop = null;
	var $fixtures = array('app.shop', 'app.city', 'app.staff');

	function startTest() {
		$this->Shop =& ClassRegistry::init('Shop');
	}

	function testShopInstance() {
		$this->assertTrue(is_a($this->Shop, 'Shop'));
	}

	function testShopFind() {
		$this->Shop->recursive = -1;
		$results = $this->Shop->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Shop' => array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'zip_code' => 'Lorem',
			'city_id' => 1,
			'address1' => 'Lorem ipsum dolor sit amet',
			'address2' => 'Lorem ipsum dolor sit amet',
			'rank' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-21 19:33:57',
			'modified' => '2010-10-21 19:33:57'
		));
		$this->assertEqual($results, $expected);
	}
}
?>