<?php 
/* SVN FILE: $Id$ */
/* StockKeepingUnit Test cases generated on: 2010-10-26 16:00:35 : 1288076435*/
App::import('Model', 'StockKeepingUnit');

class StockKeepingUnitTestCase extends CakeTestCase {
	var $StockKeepingUnit = null;
	var $fixtures = array('app.stock_keeping_unit', 'app.product');

	function startTest() {
		$this->StockKeepingUnit =& ClassRegistry::init('StockKeepingUnit');
	}

	function testStockKeepingUnitInstance() {
		$this->assertTrue(is_a($this->StockKeepingUnit, 'StockKeepingUnit'));
	}

	function testStockKeepingUnitFind() {
		$this->StockKeepingUnit->recursive = -1;
		$results = $this->StockKeepingUnit->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('StockKeepingUnit' => array(
			'id' => 1,
			'product_id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'heel' => 1,
			'size' => 'Lorem ipsum dolor sit amet',
			'price' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-26 16:00:35',
			'modified' => '2010-10-26 16:00:35'
		));
		$this->assertEqual($results, $expected);
	}
}
?>