<?php 
/* SVN FILE: $Id$ */
/* Staff Test cases generated on: 2010-10-21 19:34:35 : 1287657275*/
App::import('Model', 'Staff');

class StaffTestCase extends CakeTestCase {
	var $Staff = null;
	var $fixtures = array('app.staff', 'app.shop', 'app.knowhow', 'app.message');

	function startTest() {
		$this->Staff =& ClassRegistry::init('Staff');
	}

	function testStaffInstance() {
		$this->assertTrue(is_a($this->Staff, 'Staff'));
	}

	function testStaffFind() {
		$this->Staff->recursive = -1;
		$results = $this->Staff->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Staff' => array(
			'id' => 1,
			'shop_id' => 1,
			'staff_number' => 'Lorem ipsum dolor sit amet',
			'password' => 'Lorem ipsum dolor sit amet',
			'name' => 'Lorem ipsum dolor sit amet',
			'furigana' => 'Lorem ipsum dolor sit amet',
			'email' => 'Lorem ipsum dolor sit amet',
			'level' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-21 19:34:34',
			'modified' => '2010-10-21 19:34:34'
		));
		$this->assertEqual($results, $expected);
	}
}
?>