<?php 
/* SVN FILE: $Id$ */
/* Ranking Test cases generated on: 2010-11-05 20:14:23 : 1288955663*/
App::import('Model', 'Ranking');

class RankingTestCase extends CakeTestCase {
	var $Ranking = null;
	var $fixtures = array('app.ranking');

	function startTest() {
		$this->Ranking =& ClassRegistry::init('Ranking');
	}

	function testRankingInstance() {
		$this->assertTrue(is_a($this->Ranking, 'Ranking'));
	}

	function testRankingFind() {
		$this->Ranking->recursive = -1;
		$results = $this->Ranking->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Ranking' => array(
			'id' => 1,
			'shop_id' => 1,
			'staff_id' => 1,
			'total_date' => '2010-11-05 20:14:23',
			'shop_name' => 'Lorem ipsum dolor sit amet',
			'staff_name' => 'Lorem ipsum dolor sit amet',
			'regist_count' => 1,
			'created' => '2010-11-05 20:14:23',
			'modified' => '2010-11-05 20:14:23'
		));
		$this->assertEqual($results, $expected);
	}
}
?>