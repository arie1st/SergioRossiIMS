<?php 
/* SVN FILE: $Id$ */
/* SendShop Test cases generated on: 2010-11-23 12:08:12 : 1290481692*/
App::import('Model', 'SendShop');

class SendShopTestCase extends CakeTestCase {
	var $SendShop = null;
	var $fixtures = array('app.send_shop');

	function startTest() {
		$this->SendShop =& ClassRegistry::init('SendShop');
	}

	function testSendShopInstance() {
		$this->assertTrue(is_a($this->SendShop, 'SendShop'));
	}

	function testSendShopFind() {
		$this->SendShop->recursive = -1;
		$results = $this->SendShop->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('SendShop' => array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'rank' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-11-23 12:08:12',
			'modified' => '2010-11-23 12:08:12'
		));
		$this->assertEqual($results, $expected);
	}
}
?>