<?php 
/* SVN FILE: $Id$ */
/* Color Test cases generated on: 2010-11-04 17:52:53 : 1288860773*/
App::import('Model', 'Color');

class ColorTestCase extends CakeTestCase {
	var $Color = null;
	var $fixtures = array('app.color', 'app.color_chip');

	function startTest() {
		$this->Color =& ClassRegistry::init('Color');
	}

	function testColorInstance() {
		$this->assertTrue(is_a($this->Color, 'Color'));
	}

	function testColorFind() {
		$this->Color->recursive = -1;
		$results = $this->Color->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Color' => array(
			'id' => 1,
			'season_id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'description' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida,phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam,vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit,feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-11-04 17:52:53',
			'modified' => '2010-11-04 17:52:53'
		));
		$this->assertEqual($results, $expected);
	}
}
?>