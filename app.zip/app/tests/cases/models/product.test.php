<?php 
/* SVN FILE: $Id$ */
/* Product Test cases generated on: 2010-10-26 15:23:31 : 1288074211*/
App::import('Model', 'Product');

class ProductTestCase extends CakeTestCase {
	var $Product = null;
	var $fixtures = array('app.product', 'app.group', 'app.category', 'app.knowhow', 'app.product2colorchip', 'app.product_skus');

	function startTest() {
		$this->Product =& ClassRegistry::init('Product');
	}

	function testProductInstance() {
		$this->assertTrue(is_a($this->Product, 'Product'));
	}

	function testProductFind() {
		$this->Product->recursive = -1;
		$results = $this->Product->find('first');
		$this->assertTrue(!empty($results));

		$expected = array('Product' => array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'group_id' => 1,
			'category_id' => 1,
			'heel' => 1,
			'price' => 1,
			'delete_flg' => 1,
			'creator_id' => 1,
			'updater_id' => 1,
			'created' => '2010-10-26 15:23:31',
			'modified' => '2010-10-26 15:23:31'
		));
		$this->assertEqual($results, $expected);
	}
}
?>