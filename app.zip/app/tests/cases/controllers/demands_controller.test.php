<?php 
/* SVN FILE: $Id$ */
/* DemandsController Test cases generated on: 2010-11-29 15:41:58 : 1291012918*/
App::import('Controller', 'Demands');

class TestDemands extends DemandsController {
	var $autoRender = false;
}

class DemandsControllerTest extends CakeTestCase {
	var $Demands = null;

	function startTest() {
		$this->Demands = new TestDemands();
		$this->Demands->constructClasses();
	}

	function testDemandsControllerInstance() {
		$this->assertTrue(is_a($this->Demands, 'DemandsController'));
	}

	function endTest() {
		unset($this->Demands);
	}
}
?>