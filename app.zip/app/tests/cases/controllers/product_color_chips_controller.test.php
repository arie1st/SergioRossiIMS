<?php 
/* SVN FILE: $Id$ */
/* ProductColorChipsController Test cases generated on: 2010-11-05 16:39:50 : 1288942790*/
App::import('Controller', 'ProductColorChips');

class TestProductColorChips extends ProductColorChipsController {
	var $autoRender = false;
}

class ProductColorChipsControllerTest extends CakeTestCase {
	var $ProductColorChips = null;

	function startTest() {
		$this->ProductColorChips = new TestProductColorChips();
		$this->ProductColorChips->constructClasses();
	}

	function testProductColorChipsControllerInstance() {
		$this->assertTrue(is_a($this->ProductColorChips, 'ProductColorChipsController'));
	}

	function endTest() {
		unset($this->ProductColorChips);
	}
}
?>