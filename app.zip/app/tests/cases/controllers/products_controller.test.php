<?php 
/* SVN FILE: $Id$ */
/* ProductsController Test cases generated on: 2010-10-26 16:13:46 : 1288077226*/
App::import('Controller', 'Products');

class TestProducts extends ProductsController {
	var $autoRender = false;
}

class ProductsControllerTest extends CakeTestCase {
	var $Products = null;

	function startTest() {
		$this->Products = new TestProducts();
		$this->Products->constructClasses();
	}

	function testProductsControllerInstance() {
		$this->assertTrue(is_a($this->Products, 'ProductsController'));
	}

	function endTest() {
		unset($this->Products);
	}
}
?>