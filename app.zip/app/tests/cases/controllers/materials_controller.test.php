<?php 
/* SVN FILE: $Id$ */
/* MaterialsController Test cases generated on: 2010-10-26 16:14:54 : 1288077294*/
App::import('Controller', 'Materials');

class TestMaterials extends MaterialsController {
	var $autoRender = false;
}

class MaterialsControllerTest extends CakeTestCase {
	var $Materials = null;

	function startTest() {
		$this->Materials = new TestMaterials();
		$this->Materials->constructClasses();
	}

	function testMaterialsControllerInstance() {
		$this->assertTrue(is_a($this->Materials, 'MaterialsController'));
	}

	function endTest() {
		unset($this->Materials);
	}
}
?>