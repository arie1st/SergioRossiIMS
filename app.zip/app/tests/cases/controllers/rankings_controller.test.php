<?php 
/* SVN FILE: $Id$ */
/* RankingsController Test cases generated on: 2010-11-05 20:14:41 : 1288955681*/
App::import('Controller', 'Rankings');

class TestRankings extends RankingsController {
	var $autoRender = false;
}

class RankingsControllerTest extends CakeTestCase {
	var $Rankings = null;

	function startTest() {
		$this->Rankings = new TestRankings();
		$this->Rankings->constructClasses();
	}

	function testRankingsControllerInstance() {
		$this->assertTrue(is_a($this->Rankings, 'RankingsController'));
	}

	function endTest() {
		unset($this->Rankings);
	}
}
?>