<?php 
/* SVN FILE: $Id$ */
/* StockKeepingUnitsController Test cases generated on: 2010-10-26 16:14:05 : 1288077245*/
App::import('Controller', 'StockKeepingUnits');

class TestStockKeepingUnits extends StockKeepingUnitsController {
	var $autoRender = false;
}

class StockKeepingUnitsControllerTest extends CakeTestCase {
	var $StockKeepingUnits = null;

	function startTest() {
		$this->StockKeepingUnits = new TestStockKeepingUnits();
		$this->StockKeepingUnits->constructClasses();
	}

	function testStockKeepingUnitsControllerInstance() {
		$this->assertTrue(is_a($this->StockKeepingUnits, 'StockKeepingUnitsController'));
	}

	function endTest() {
		unset($this->StockKeepingUnits);
	}
}
?>