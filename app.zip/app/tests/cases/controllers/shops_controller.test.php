<?php 
/* SVN FILE: $Id$ */
/* ShopsController Test cases generated on: 2010-10-21 19:36:47 : 1287657407*/
App::import('Controller', 'Shops');

class TestShops extends ShopsController {
	var $autoRender = false;
}

class ShopsControllerTest extends CakeTestCase {
	var $Shops = null;

	function startTest() {
		$this->Shops = new TestShops();
		$this->Shops->constructClasses();
	}

	function testShopsControllerInstance() {
		$this->assertTrue(is_a($this->Shops, 'ShopsController'));
	}

	function endTest() {
		unset($this->Shops);
	}
}
?>