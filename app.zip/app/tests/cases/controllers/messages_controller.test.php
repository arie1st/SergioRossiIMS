<?php 
/* SVN FILE: $Id$ */
/* MessagesController Test cases generated on: 2010-10-21 19:37:43 : 1287657463*/
App::import('Controller', 'Messages');

class TestMessages extends MessagesController {
	var $autoRender = false;
}

class MessagesControllerTest extends CakeTestCase {
	var $Messages = null;

	function startTest() {
		$this->Messages = new TestMessages();
		$this->Messages->constructClasses();
	}

	function testMessagesControllerInstance() {
		$this->assertTrue(is_a($this->Messages, 'MessagesController'));
	}

	function endTest() {
		unset($this->Messages);
	}
}
?>