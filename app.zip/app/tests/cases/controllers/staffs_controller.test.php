<?php 
/* SVN FILE: $Id$ */
/* StaffsController Test cases generated on: 2010-10-21 19:37:00 : 1287657420*/
App::import('Controller', 'Staffs');

class TestStaffs extends StaffsController {
	var $autoRender = false;
}

class StaffsControllerTest extends CakeTestCase {
	var $Staffs = null;

	function startTest() {
		$this->Staffs = new TestStaffs();
		$this->Staffs->constructClasses();
	}

	function testStaffsControllerInstance() {
		$this->assertTrue(is_a($this->Staffs, 'StaffsController'));
	}

	function endTest() {
		unset($this->Staffs);
	}
}
?>