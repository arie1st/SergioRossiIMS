<?php 
/* SVN FILE: $Id$ */
/* ColorsController Test cases generated on: 2010-11-04 17:53:14 : 1288860794*/
App::import('Controller', 'Colors');

class TestColors extends ColorsController {
	var $autoRender = false;
}

class ColorsControllerTest extends CakeTestCase {
	var $Colors = null;

	function startTest() {
		$this->Colors = new TestColors();
		$this->Colors->constructClasses();
	}

	function testColorsControllerInstance() {
		$this->assertTrue(is_a($this->Colors, 'ColorsController'));
	}

	function endTest() {
		unset($this->Colors);
	}
}
?>