<?php 
/* SVN FILE: $Id$ */
/* KnowhowsController Test cases generated on: 2010-10-21 19:37:16 : 1287657436*/
App::import('Controller', 'Knowhows');

class TestKnowhows extends KnowhowsController {
	var $autoRender = false;
}

class KnowhowsControllerTest extends CakeTestCase {
	var $Knowhows = null;

	function startTest() {
		$this->Knowhows = new TestKnowhows();
		$this->Knowhows->constructClasses();
	}

	function testKnowhowsControllerInstance() {
		$this->assertTrue(is_a($this->Knowhows, 'KnowhowsController'));
	}

	function endTest() {
		unset($this->Knowhows);
	}
}
?>