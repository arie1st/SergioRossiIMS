<?php 
/* SVN FILE: $Id$ */
/* ColorChipsController Test cases generated on: 2010-10-26 16:15:18 : 1288077318*/
App::import('Controller', 'ColorChips');

class TestColorChips extends ColorChipsController {
	var $autoRender = false;
}

class ColorChipsControllerTest extends CakeTestCase {
	var $ColorChips = null;

	function startTest() {
		$this->ColorChips = new TestColorChips();
		$this->ColorChips->constructClasses();
	}

	function testColorChipsControllerInstance() {
		$this->assertTrue(is_a($this->ColorChips, 'ColorChipsController'));
	}

	function endTest() {
		unset($this->ColorChips);
	}
}
?>