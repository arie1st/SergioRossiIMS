<?php 
/* SVN FILE: $Id$ */
/* SendShopsController Test cases generated on: 2010-11-23 12:08:28 : 1290481708*/
App::import('Controller', 'SendShops');

class TestSendShops extends SendShopsController {
	var $autoRender = false;
}

class SendShopsControllerTest extends CakeTestCase {
	var $SendShops = null;

	function startTest() {
		$this->SendShops = new TestSendShops();
		$this->SendShops->constructClasses();
	}

	function testSendShopsControllerInstance() {
		$this->assertTrue(is_a($this->SendShops, 'SendShopsController'));
	}

	function endTest() {
		unset($this->SendShops);
	}
}
?>