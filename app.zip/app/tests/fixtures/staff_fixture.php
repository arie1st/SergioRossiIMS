<?php 
/* SVN FILE: $Id$ */
/* Staff Fixture generated on: 2010-10-21 19:34:34 : 1287657274*/

class StaffFixture extends CakeTestFixture {
	var $name = 'Staff';
	var $table = 'staffs';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'shop_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'staff_number' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'password' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'name' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'furigana' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'email' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'level' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'delete_flg' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'shop_id' => 1,
		'staff_number' => 'Lorem ipsum dolor sit amet',
		'password' => 'Lorem ipsum dolor sit amet',
		'name' => 'Lorem ipsum dolor sit amet',
		'furigana' => 'Lorem ipsum dolor sit amet',
		'email' => 'Lorem ipsum dolor sit amet',
		'level' => 1,
		'delete_flg' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-10-21 19:34:34',
		'modified' => '2010-10-21 19:34:34'
	));
}
?>