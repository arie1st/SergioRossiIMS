<?php 
/* SVN FILE: $Id$ */
/* Message Fixture generated on: 2010-10-21 19:35:48 : 1287657348*/

class MessageFixture extends CakeTestFixture {
	var $name = 'Message';
	var $table = 'messages';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'staff_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'from_shop_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'to_shop_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'staff_name' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'subject' => array('type'=>'string', 'null' => false, 'default' => NULL, 'length' => 800),
		'body' => array('type'=>'text', 'null' => false, 'default' => NULL),
		'approve_flg' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'delete_flg' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'staff_id' => 1,
		'from_shop_id' => 1,
		'to_shop_id' => 1,
		'staff_name' => 'Lorem ipsum dolor sit amet',
		'subject' => 'Lorem ipsum dolor sit amet',
		'body' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida,phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam,vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit,feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
		'approve_flg' => 1,
		'delete_flg' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-10-21 19:35:48',
		'modified' => '2010-10-21 19:35:48'
	));
}
?>