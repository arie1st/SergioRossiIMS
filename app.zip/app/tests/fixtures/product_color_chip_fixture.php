<?php 
/* SVN FILE: $Id$ */
/* ProductColorChip Fixture generated on: 2010-11-05 16:35:21 : 1288942521*/

class ProductColorChipFixture extends CakeTestFixture {
	var $name = 'ProductColorChip';
	var $table = 'product_color_chips';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'product_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'color_chip_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'product_id' => 1,
		'color_chip_id' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-11-05 16:35:21',
		'modified' => '2010-11-05 16:35:21'
	));
}
?>