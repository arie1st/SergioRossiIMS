<?php 
/* SVN FILE: $Id$ */
/* Product2colorchip Fixture generated on: 2010-10-26 16:01:24 : 1288076484*/

class Product2colorchipFixture extends CakeTestFixture {
	var $name = 'Product2colorchip';
	var $table = 'product2colorchips';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'product_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'color_chip_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'product_id' => 1,
		'color_chip_id' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-10-26 16:01:24',
		'modified' => '2010-10-26 16:01:24'
	));
}
?>