<?php 
/* SVN FILE: $Id$ */
/* StockKeepingUnit Fixture generated on: 2010-10-26 16:00:35 : 1288076435*/

class StockKeepingUnitFixture extends CakeTestFixture {
	var $name = 'StockKeepingUnit';
	var $table = 'stock_keeping_units';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'product_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'name' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'heel' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'size' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'price' => array('type'=>'float', 'null' => true, 'default' => NULL, 'length' => 10),
		'delete_flg' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'product_id' => 1,
		'name' => 'Lorem ipsum dolor sit amet',
		'heel' => 1,
		'size' => 'Lorem ipsum dolor sit amet',
		'price' => 1,
		'delete_flg' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-10-26 16:00:35',
		'modified' => '2010-10-26 16:00:35'
	));
}
?>