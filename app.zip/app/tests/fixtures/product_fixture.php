<?php 
/* SVN FILE: $Id$ */
/* Product Fixture generated on: 2010-10-26 15:23:31 : 1288074211*/

class ProductFixture extends CakeTestFixture {
	var $name = 'Product';
	var $table = 'products';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'name' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'group_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'category_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'heel' => array('type'=>'float', 'null' => true, 'default' => NULL, 'length' => 10),
		'price' => array('type'=>'float', 'null' => true, 'default' => NULL, 'length' => 10),
		'delete_flg' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'name' => 'Lorem ipsum dolor sit amet',
		'group_id' => 1,
		'category_id' => 1,
		'heel' => 1,
		'price' => 1,
		'delete_flg' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-10-26 15:23:31',
		'modified' => '2010-10-26 15:23:31'
	));
}
?>