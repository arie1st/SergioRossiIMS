<?php 
/* SVN FILE: $Id$ */
/* City Fixture generated on: 2010-10-20 15:37:27 : 1287556647*/

class CityFixture extends CakeTestFixture {
	var $name = 'City';
	var $table = 'cities';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'name' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'name' => 'Lorem ipsum dolor sit amet',
		'created' => '2010-10-20 15:37:27',
		'modified' => '2010-10-20 15:37:27'
	));
}
?>