<?php 
/* SVN FILE: $Id$ */
/* Ranking Fixture generated on: 2010-11-05 20:14:23 : 1288955663*/

class RankingFixture extends CakeTestFixture {
	var $name = 'Ranking';
	var $table = 'rankings';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'shop_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'staff_id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20),
		'total_date' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'shop_name' => array('type'=>'string', 'null' => true, 'default' => NULL),
		'staff_name' => array('type'=>'string', 'null' => true, 'default' => NULL),
		'regist_count' => array('type'=>'float', 'null' => true, 'default' => NULL, 'length' => 10),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'shop_id' => 1,
		'staff_id' => 1,
		'total_date' => '2010-11-05 20:14:23',
		'shop_name' => 'Lorem ipsum dolor sit amet',
		'staff_name' => 'Lorem ipsum dolor sit amet',
		'regist_count' => 1,
		'created' => '2010-11-05 20:14:23',
		'modified' => '2010-11-05 20:14:23'
	));
}
?>