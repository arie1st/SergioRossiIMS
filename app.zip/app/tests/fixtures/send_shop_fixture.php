<?php 
/* SVN FILE: $Id$ */
/* SendShop Fixture generated on: 2010-11-23 12:08:12 : 1290481692*/

class SendShopFixture extends CakeTestFixture {
	var $name = 'SendShop';
	var $table = 'send_shops';
	var $fields = array(
		'id' => array('type'=>'integer', 'null' => false, 'default' => NULL, 'length' => 20, 'key' => 'primary'),
		'name' => array('type'=>'string', 'null' => false, 'default' => NULL),
		'rank' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'delete_flg' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 4),
		'creator_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'updater_id' => array('type'=>'integer', 'null' => false, 'default' => '0', 'length' => 20),
		'created' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'modified' => array('type'=>'datetime', 'null' => false, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1))
	);
	var $records = array(array(
		'id' => 1,
		'name' => 'Lorem ipsum dolor sit amet',
		'rank' => 1,
		'delete_flg' => 1,
		'creator_id' => 1,
		'updater_id' => 1,
		'created' => '2010-11-23 12:08:12',
		'modified' => '2010-11-23 12:08:12'
	));
}
?>