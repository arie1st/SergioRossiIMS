<?php
class Content extends AppModel {

	var $name = 'Content';

	var $validate = array(
		'name' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"コンテンツ番号は数字で入力してください。"),
//			'rule2' => array('rule' => array('Unipue', 'name', 'name'), 'message' =>"カラー名は使われています。"),
			),
	);

	function Unipue( $var, $targetname, $fixename ) {
		$return = true;
		$cond = array(
				$targetname => $var[$fixename]
			);
		$data = $this->findAll($cond);
		
		if ( count($data) != 0 ) {
			$return = false;
		}
		return $return;
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Season' => array(
			'className' => 'Season',
			'foreignKey' => 'season_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
	);

}
?>