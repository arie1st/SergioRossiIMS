<?php

App::import('Model', 'Shop');

class Message extends AppModel {

	var $name = 'Message';

	var $validate = array(
		'staff_id' => array('numeric'),
//		'from_shop_id' => array('rule' => VALID_NOT_EMPTY, 'message' =>"送信元店舗を選択してください。"),
		'to_shop_id' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"店舗を選択してください。"),
			'rule2' => array('rule' => 'numeric', 'message' =>"店舗を選択してください。"),
			),
//		'password' => array('numeric'),
		'subject' => array('rule' => VALID_NOT_EMPTY, 'message' =>"件名を入力してください。"),
		'body' => array('rule' => VALID_NOT_EMPTY, 'message' =>"内容を入力してください。"),
//		'category_id' => array('rule' => VALID_NOT_EMPTY, 'message' =>"カテゴリーを選択してください。"),
//		'description1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"説明を入力してください。"),
//		'key_string' => array(
//			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"入力された文字は確認用の文字と一致しません。"),
//			'rule2' => array('rule' => array('CaptchaCheck', 'captcha_keystring', 'key_string'), 'message' =>"入力された文字は確認用の文字と一致しません。")
//			)
	);

	function getStaffShop( $userId ) {
		$Shop= new Shop;
		$cond = array(
			'Shop.id' => array( $userId ),
			);
		$userShop = $Shop->find( 'first', array(
			'conditions' => $cond,
			'fields' => array( 'Shop.name' ),
		));
		return $userShop;	
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Staff' => array(
			'className' => 'Staff',
			'foreignKey' => 'staff_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'ShopFrom' => array(
			'className' => 'Shop',
			'foreignKey' => 'from_shop_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'ShopTo' => array(
			'className' => 'Shop',
			'foreignKey' => 'to_shop_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
	);

}
?>