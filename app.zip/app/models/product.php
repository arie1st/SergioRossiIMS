<?php
class Product extends AppModel {

	var $name = 'Product';

	var $validate = array(
		'name' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"スタッフ番号は数字で入力してください。"),
//			'rule2' => array('rule' => array('Unipue', 'Product.name', 'name'), 'message' =>"スタッフ番号は使われています。"),
			),
	);

	function Unipue( $var, $targetname, $fixename ) {
		$return = true;
		$cond = array(
				$targetname => $var[$fixename]
			);
		$data = $this->findAll($cond);
		
		if ( count($data) != 0 ) {
			$return = false;
		}
		return $return;
	}

	function getStaffShop( $userId ) {
		$Shop= new Shop;
		$cond = array(
			'Shop.id' => array( $userId ),
			);
		$userShop = $Shop->find( 'first', array(
			'conditions' => $cond,
			'fields' => array( 'Shop.name' ),
		));
		return $userShop;	
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Season' => array(
			'className' => 'Season',
			'foreignKey' => 'season_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Group' => array(
			'className' => 'Group',
			'foreignKey' => 'group_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Category' => array(
			'className' => 'Category',
			'foreignKey' => 'category_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
	);

	var $hasMany = array(
		'ProductColorChip' => array(
			'className' => 'ProductColorChip',
			'foreignKey' => 'product_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'Knowhow' => array(
			'className' => 'Knowhow',
			'foreignKey' => 'product_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
	);

}
?>