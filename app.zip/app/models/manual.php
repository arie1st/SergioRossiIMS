<?php
class Manual extends AppModel {

//	var $name = 'Manual';
	var $uses = null;

	function getStaffShop( $userId ) {
		$Shop= new Shop;
		$cond = array(
			'Shop.id' => array( $userId ),
			);
		$userShop = $Shop->find( 'first', array(
			'conditions' => $cond,
			'fields' => array( 'Shop.name' ),
		));
		return $userShop;	
	}

}
?>