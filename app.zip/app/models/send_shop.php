<?php
class SendShop extends AppModel {

	var $name = 'SendShop';

}
?>