<?php

App::import('Model', 'Shop');

class Knowhow extends AppModel {

	var $name = 'Knowhow';

	var $validate = array(
		'state_id' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"ジャンルを選択してください。"),
			'rule2' => array('rule' => 'numeric', 'message' =>"ジャンルを選択してください。"),
			),
		'send_shop_id' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"書き込み先を選択してください。"),
			'rule2' => array('rule' => 'numeric', 'message' =>"書き込み先を選択してください。"),
			),
		'subject' => array('rule' => VALID_NOT_EMPTY, 'message' =>"件名を入力してください。"),
	);

	function getStaffShop( $userId ) {
		$Shop= new Shop;
		$cond = array(
			'Shop.id' => array($userId),
			);
		$userShop = $Shop->find('first', array(
			'conditions' => $cond,
			'fields' => array('Shop.name'),
		));
		return $userShop;	
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Staff' => array(
			'className' => 'Staff',
			'foreignKey' => 'staff_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'SendShop' => array(
			'className' => 'SendShop',
			'foreignKey' => 'send_shop_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'State' => array(
			'className' => 'State',
			'foreignKey' => 'state_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
	);
}
?>