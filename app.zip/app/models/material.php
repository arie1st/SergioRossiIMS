<?php
class Material extends AppModel {

	var $name = 'Material';

	var $validate = array(
		'name' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"マテリアル番号は数字で入力してください。"),
//			'rule2' => array('rule' => array('Unipue', 'name', 'name'), 'message' =>"マテリアル名は使われています。"),
			),
	);

	function Unipue( $var, $targetname, $fixename ) {
		$return = true;
		$cond = array(
				$targetname => $var[$fixename]
			);
		$data = $this->findAll($cond);
		
		if ( count($data) != 0 ) {
			$return = false;
		}
		return $return;
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $hasMany = array(
		'ColorChip' => array(
			'className' => 'ColorChip',
			'foreignKey' => 'material_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>