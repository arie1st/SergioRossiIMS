<?php
class Category extends AppModel {

	var $name = 'Category';

//	var $validate = array(
//		'name' => array(
//			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"スタッフ番号は数字で入力してください。"),
//			'rule2' => array('rule' => array('Unipue', 'name', 'name'), 'message' =>"スタッフ番号は使われています。"),
//			),
//	);

	function Unipue( $var, $targetname, $fixename ) {
		$return = true;
		$cond = array(
				$targetname => $var[$fixename]
			);
		$data = $this->findAll($cond);
		
		if ( count($data) != 0 ) {
			$return = false;
		}
		return $return;
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Season' => array(
			'className' => 'Season',
			'foreignKey' => 'season_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
	);

	var $hasMany = array(
		'Product' => array(
			'className' => 'Product',
			'foreignKey' => 'category_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>