<?php

App::import('Model', 'Shop');

class Demand extends AppModel {

	var $name = 'Demand';

	var $validate = array(
		'subject' => array('rule' => VALID_NOT_EMPTY, 'message' =>"件名を入力してください。"),
		'body' => array('rule' => VALID_NOT_EMPTY, 'message' =>"内容を入力してください。"),
	);

	function getStaffShop( $userId ) {
		$Shop= new Shop;
		$cond = array(
			'Shop.id' => array($userId),
			);
		$userShop = $Shop->find('first', array(
			'conditions' => $cond,
			'fields' => array('Shop.name'),
		));
		return $userShop;	
	}

}
?>