<?php
class Staff extends AppModel {

	var $name = 'Staff';

	var $validate = array(
		'shop_id' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"店舗を選択してください。"),
			'rule2' => array('rule' => 'numeric', 'message' =>"店舗を選択してください。"),
			),
		'staff_number' => array(
			'rule1' => array('rule' => 'numeric', 'message' =>"スタッフ番号は数字で入力してください。"),
			'rule2' => array('rule' => array('Unipue', 'staff_number', 'staff_number'), 'message' =>"スタッフ番号は使われています。"),
			'rule3' => array('rule' => VALID_NOT_EMPTY, 'message' =>"スタッフ番号を入力してください。"),
			),
		'name' => array('rule' => VALID_NOT_EMPTY, 'message' =>"名前を入力してください。"),
		'password1' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"パスワードを入力してください。"),
			'rule2' => array('rule' => array('ValueMache', 'password1', 'password2'), 'message' =>"パスワードが合っていません。")
			),
//		'email' => 
//			array(
//			'rule1' => array('rule' => "email", 'message' =>"メールアドレスの形式が間違っています。"),
//			'rule2' => array('rule' => array('Unipue', 'email', 'email'), 'message' =>"入力されましたメールアドレスは既に登録されています。"),
//			),
	);

	var $validateCsv = array(
		'shop_id' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"店舗を選択してください。"),
			'rule2' => array('rule' => 'numeric', 'message' =>"店舗を選択してください。"),
			'rule3' => array('rule' => array('CheckShop', 'shop_id' ), 'message' =>"店舗は登録されていません。"),
			),
		'staff_number' => array(
			'rule1' => array('rule' => 'numeric', 'message' =>"スタッフ番号は数字で入力してください。"),
			'rule2' => array('rule' => array('Unipue', 'staff_number', 'staff_number'), 'message' =>"スタッフ番号は使われています。"),
			'rule3' => array('rule' => VALID_NOT_EMPTY, 'message' =>"スタッフ番号を入力してください。"),
			),
		'name' => array('rule' => VALID_NOT_EMPTY, 'message' =>"名前を入力してください。"),
		'password' => array(
			'rule1' => array('rule' => VALID_NOT_EMPTY, 'message' =>"パスワードを入力してください。"),
			),
//		'email' => 
//			array(
//			'rule1' => array('rule' => "email", 'message' =>"メールアドレスの形式が間違っています。"),
//			'rule2' => array('rule' => array('Unipue', 'email', 'email'), 'message' =>"入力されましたメールアドレスは既に登録されています。"),
//			),
	);

	
	function Unipue( $var, $targetname, $fixename ) {
		$return = true;
		$cond = array(
				$targetname => $var[$fixename]
			);
		$data = $this->findAll($cond);
		
		if ( count($data) != 0 ) {
			$return = false;
		}
		return $return;
	}
	
	function ValueMache( $var, $targetname, $fixename ) {
		$return = true;
		if ( $this->data[$this->name][$targetname] != $this->data[$this->name][$fixename] ) {
			$return = false;
		}
		return $return;
	}
	
	function CheckShop( $var, $shop_id ) {
		$return = true;
		$cond = array(
				'Shop.id' => $this->data[$this->name][$shop_id]
			);
		$data = $this->Shop->findAll($cond);

		if ( count($data) == 0 ) {
			$return = false;
		}
		return $return;
	}
	
	function SearchShop( $name ) {
		$cond = array(
			'Shop.cost_center_no' => $name
		);
		$return = $this->Shop->find('first', array(
			'conditions' => $cond
		));
		return $return;
	}

	function getStaffShop( $userId ) {
		$Shop= new Shop;
		$cond = array(
			'Shop.id' => array( $userId ),
			);
		$userShop = $Shop->find( 'first', array(
			'conditions' => $cond,
			'fields' => array( 'Shop.name' ),
		));
		return $userShop;	
	}

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
		'Shop' => array(
			'className' => 'Shop',
			'foreignKey' => 'shop_id',
			'conditions' => array('Shop.delete_flg' => '0'),
			'fields' => '',
			'order' => ''
		)
	);

	var $hasMany = array(
		'Knowhow' => array(
			'className' => 'Knowhow',
			'foreignKey' => 'staff_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'Message' => array(
			'className' => 'Message',
			'foreignKey' => 'staff_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>