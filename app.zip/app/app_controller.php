<?php
class AppController extends Controller {
	var $helpers = array('Html', 'Form', 'Javascript');
	// AuthComponentの宣言
//	var $components = array('Auth');

//	var $needAuth = false;

	function beforeFilter() {
		
//		$this->Auth->userModel = 'Staff';
//		$this->Auth->fields = array('username'=>'staff_number', 'password'=>'password');


		//-- セッションから取り出したログイン情報をセット
//		$auth = $this->Session->read('auth');
//		$this->set("auth", $auth);

		//-- ログイン必須の機能でログインされていない場合はログイン画面へ転送
//		if ( $this->needAuth ) {
//			if ( empty($auth) ) {
//				$this->redirect("/users/login");
//				return;
//			}
//		}
	}

}
?>
